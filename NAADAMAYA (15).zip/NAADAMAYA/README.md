# NAADAMAYA

sing. evolve. globally.

- `src/`, `package.json`, `vite.config.js` ... : React + Vite + Tailwind frontend (project root)
- `backend/` : FastAPI + PostgreSQL + Redis + Celery backend (see `backend/README.md`)

## Run

1. Backend: `cd backend && cp .env.example .env` (fill in secrets) then `docker compose up --build`
2. Frontend (in a second terminal, from this folder): `npm install && npm run dev`, then open http://localhost:5173
3. In development the OTP is `123456` and the login screen shows it.

All fixes noted during the build are already applied in these files. The frontend build was checked
(`vite build` succeeds); the backend compiles but has not been run against a live database.

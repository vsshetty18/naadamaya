import { useEffect, useRef, useState } from 'react'
import { Pause, Play, Minus, Plus } from 'lucide-react'

import { TALAS, TalaClock } from '@/audio/tala'
import { cn } from '@/utils/cn'

const LABEL = { X: 'X', 0: '0', 2: '2', 3: '3', 4: '4', '.': '' }

export default function TalaPanel() {
  const [talaId, setTalaId] = useState('teen')
  const [bpm, setBpm] = useState(80)
  const [on, setOn] = useState(false)
  const [beat, setBeat] = useState(-1)
  const taps = useRef([])
  const clock = useRef(null)
  if (!clock.current) clock.current = new TalaClock((i) => setBeat(i))
  const tala = TALAS.find((t) => t.id === talaId)

  useEffect(() => {
    clock.current.configure({ tala, bpm })
  }, [tala, bpm])
  useEffect(() => () => clock.current?.stop(), [])

  const toggle = () => {
    if (on) {
      clock.current.stop()
      setBeat(-1)
    } else {
      clock.current.start()
    }
    setOn(!on)
  }
  const pick = (id) => {
    setTalaId(id)
    if (on) {
      clock.current.stop()
      setOn(false)
      setBeat(-1)
    }
  }
  const tap = () => {
    const now = performance.now()
    taps.current = [...taps.current.filter((t) => now - t < 2500), now]
    if (taps.current.length >= 3) {
      const gaps = taps.current.slice(1).map((t, i) => t - taps.current[i])
      const avg = gaps.reduce((a, b) => a + b, 0) / gaps.length
      setBpm(Math.max(20, Math.min(300, Math.round(60000 / avg))))
    }
  }

  let at = 0
  const groups = tala.split.map((len) => {
    const g = tala.marks.slice(at, at + len).map((m, k) => ({ mark: m, i: at + k }))
    at += len
    return g
  })

  return (
    <section className="rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
      <h2 className="font-serif text-[1.15rem] font-semibold text-brown-900">Tala keeper</h2>
      <p className="mt-1 text-[0.88rem] text-brown-500">X is sam, 2 3 4 are tali (clap), 0 is khali (wave). Beats per minute is the speed of each matra.</p>

      <div className="mt-4 flex flex-wrap gap-2">
        {TALAS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => pick(t.id)}
            className={cn('rounded-full border px-3 py-1.5 text-[0.85rem] font-medium', t.id === talaId ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 bg-white/70 text-brown-700')}
          >
            {t.name} <span className="opacity-70">{t.beats}</span>
          </button>
        ))}
      </div>

      <div className="mt-5 flex flex-wrap justify-center gap-x-4 gap-y-3" aria-live="off">
        {groups.map((g, gi) => (
          <div key={gi} className="flex gap-1.5">
            {g.map(({ mark, i }) => (
              <div
                key={i}
                className={cn(
                  'flex h-9 w-9 items-center justify-center rounded-full border text-[0.8rem] font-semibold transition-colors duration-75',
                  beat === i ? 'border-gold-500 bg-gold-400 text-white' : mark === 'X' ? 'border-brown-500 text-brown-800' : 'border-brown-200 text-brown-500'
                )}
                title={`Beat ${i + 1}`}
              >
                {LABEL[mark] || i + 1}
              </div>
            ))}
          </div>
        ))}
      </div>

      <div className="mt-6 flex items-center justify-center gap-4">
        <button type="button" aria-label="Slower" onClick={() => setBpm((b) => Math.max(20, b - 2))} className="flex h-10 w-10 items-center justify-center rounded-full border border-brown-200">
          <Minus className="h-4 w-4" aria-hidden="true" />
        </button>
        <div className="text-center">
          <div className="font-serif text-[2.4rem] font-semibold leading-none text-brown-800">{bpm}</div>
          <div className="text-[0.75rem] text-brown-400">beats per minute</div>
        </div>
        <button type="button" aria-label="Faster" onClick={() => setBpm((b) => Math.min(300, b + 2))} className="flex h-10 w-10 items-center justify-center rounded-full border border-brown-200">
          <Plus className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
      <input type="range" min="20" max="300" value={bpm} onChange={(e) => setBpm(Number(e.target.value))} aria-label="Tempo" className="mt-3 h-2 w-full accent-[#93582F]" />

      <div className="mt-4 flex gap-3">
        <button type="button" onClick={toggle} aria-pressed={on} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-brown-600 px-5 py-3.5 text-[1rem] font-medium text-white">
          {on ? <Pause className="h-5 w-5" aria-hidden="true" /> : <Play className="h-5 w-5" aria-hidden="true" />}
          {on ? 'Stop' : 'Start'}
        </button>
        <button type="button" onClick={tap} className="rounded-full border border-brown-300 px-5 py-3.5 text-[0.95rem] font-medium text-brown-700">
          Tap tempo
        </button>
      </div>
    </section>
  )
}

import { useEffect, useRef, useState } from 'react'
import { Pause, Play, Volume2 } from 'lucide-react'

import { Tanpura, SPEEDS, STRING_CHOICES } from '@/audio/tanpura'
import { playTone } from '@/audio/engine'
import { NOTE_NAMES, SWARA_NAMES, midiToFreq } from '@/utils/music'
import { cn } from '@/utils/cn'

const chip = (on) =>
  cn(
    'rounded-full border px-3.5 py-2 text-[0.88rem] font-medium transition-colors',
    on ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 bg-white/70 text-brown-700 hover:bg-brown-50'
  )

export default function TanpuraPanel({ tonic }) {
  const tp = useRef(null)
  if (!tp.current) tp.current = new Tanpura()
  const [on, setOn] = useState(false)
  const [fifth, setFifth] = useState(7)
  const [speed, setSpeed] = useState('medium')
  const [volume, setVolume] = useState(0.6)
  const gap = SPEEDS.find((s) => s.id === speed).gap

  useEffect(() => {
    tp.current.configure({ saMidi: tonic.saMidi, fifth, gap, volume })
  }, [tonic.saMidi, fifth, gap, volume])

  useEffect(() => () => tp.current?.stop(), [])

  const toggle = () => {
    if (on) tp.current.stop()
    else tp.current.start()
    setOn(!on)
  }

  const label = (i) => {
    const w = NOTE_NAMES[(tonic.pitchClass + i) % 12]
    return tonic.notation === 'western' ? w : tonic.notation === 'swara' ? SWARA_NAMES[i] : `${SWARA_NAMES[i]} · ${w}`
  }

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
        <h2 className="font-serif text-[1.15rem] font-semibold text-brown-900">Tanpura</h2>
        <p className="mt-1 text-[0.88rem] text-brown-500">A drone in your Sa to sing against. Pick your Sa above, then press play.</p>

        <button
          type="button"
          onClick={toggle}
          aria-pressed={on}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-brown-600 px-5 py-3.5 text-[1rem] font-medium text-white"
        >
          {on ? <Pause className="h-5 w-5" aria-hidden="true" /> : <Play className="h-5 w-5" aria-hidden="true" />}
          {on ? 'Stop tanpura' : 'Start tanpura'}
        </button>

        <p className="mt-4 text-[0.8rem] font-medium uppercase tracking-wide text-brown-400">First string</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {STRING_CHOICES.map((s) => (
            <button key={s.id} type="button" onClick={() => setFifth(s.id)} className={chip(fifth === s.id)}>
              {s.label}
            </button>
          ))}
        </div>

        <p className="mt-4 text-[0.8rem] font-medium uppercase tracking-wide text-brown-400">Speed</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {SPEEDS.map((s) => (
            <button key={s.id} type="button" onClick={() => setSpeed(s.id)} className={chip(speed === s.id)}>
              {s.label}
            </button>
          ))}
        </div>

        <label className="mt-4 flex items-center gap-3 text-[0.88rem] text-brown-700">
          <Volume2 className="h-4 w-4 shrink-0" aria-hidden="true" />
          <span className="sr-only">Volume</span>
          <input type="range" min="0.1" max="1" step="0.05" value={volume} onChange={(e) => setVolume(Number(e.target.value))} className="h-2 w-full accent-[#93582F]" />
        </label>
      </section>

      <section className="rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
        <h2 className="font-serif text-[1.15rem] font-semibold text-brown-900">Ear training</h2>
        <p className="mt-1 text-[0.88rem] text-brown-500">Tap a swara to hear it against your Sa, then sing it back. Lowercase is komal, ′ is tivra.</p>
        <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
          {SWARA_NAMES.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => playTone(midiToFreq(tonic.saMidi + i))}
              className="rounded-xl border border-brown-200 bg-white/80 px-2 py-3 text-[0.9rem] font-medium text-brown-800 active:bg-blush-100"
            >
              {label(i)}
            </button>
          ))}
          <button
            type="button"
            onClick={() => playTone(midiToFreq(tonic.saMidi + 12))}
            className="rounded-xl border border-brown-200 bg-white/80 px-2 py-3 text-[0.9rem] font-medium text-brown-800 active:bg-blush-100"
          >
            {tonic.notation === 'western' ? NOTE_NAMES[tonic.pitchClass] : 'Sa (tara)'}
          </button>
        </div>
      </section>
    </div>
  )
}

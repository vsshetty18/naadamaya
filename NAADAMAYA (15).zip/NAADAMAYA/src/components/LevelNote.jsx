import { Link } from 'react-router-dom'

const EXPERT_ROWS = [
  ['median_abs_error_cents', 'Typical pitch error', (v) => `${v} cents`],
  ['matched_percent', 'Time within pitch tolerance', (v) => `${Math.round(v)}%`],
  ['mean_deviation_cents', 'Average pitch offset', (v) => `${v > 0 ? '+' : ''}${v} cents (${v > 0 ? 'sharp' : v < 0 ? 'flat' : 'centred'})`],
  ['high_note_error_cents', 'Error on high notes', (v) => `${v} cents`],
  ['low_note_error_cents', 'Error on low notes', (v) => `${v} cents`],
  ['typical_spread_cents', 'Held-note steadiness', (v) => `${v} cents spread`],
  ['high_note_spread_cents', 'High held-note steadiness', (v) => `${v} cents spread`],
  ['vibrato_share', 'Held notes with vibrato', (v) => `${Math.round(v * 100)}%`],
  ['vibrato_rate_hz', 'Vibrato rate', (v) => `${v} Hz`],
  ['vibrato_extent_cents', 'Vibrato width', (v) => `${v} cents`],
  ['median_abs_lag_ms', 'Typical timing offset', (v) => `${v} ms`],
  ['mean_lag_ms', 'Average timing (+ late, - early)', (v) => `${v > 0 ? '+' : ''}${v} ms`],
]

/** Which level this report was scored for, plus measured numbers for advanced and professional singers. */
export default function LevelNote({ level, levelLabel, expert }) {
  if (!level) return null
  const detailed = level === 'advanced' || level === 'professional'
  const rows = detailed && expert ? EXPERT_ROWS.filter(([k]) => Number.isFinite(Number(expert[k]))) : []
  return (
    <section aria-label="Scoring level" className="nm-card animate-fade-up p-4 sm:p-5">
      <p className="text-[0.88rem] text-brown-600">
        Scored for <b className="text-brown-800">{levelLabel || level}</b> level.{' '}
        <Link to="/profile" className="text-brown-500 underline underline-offset-2">Change level</Link>
      </p>
      {rows.length > 0 && (
        <dl className="mt-3 grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2">
          {rows.map(([k, label, fmt]) => (
            <div key={k} className="flex items-baseline justify-between gap-3 border-b border-brown-100/70 py-1.5 text-[0.88rem]">
              <dt className="text-brown-500">{label}</dt>
              <dd className="font-medium text-brown-800">{fmt(Number(expert[k]))}</dd>
            </div>
          ))}
        </dl>
      )}
    </section>
  )
}

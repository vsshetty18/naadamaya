import { useCallback, useEffect, useState } from 'react'
import { Flame, Minus, Plus, TrendingDown, TrendingUp } from 'lucide-react'

import { getWeeklyReport } from '@/services/api/analysis'
import { updateProfile } from '@/services/api/library'
import { cn } from '@/utils/cn'

const DAY = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']

/**
 * "Your practice": streak, today's goal, the last 7 days and how this week compares.
 * Everything comes from the singer's completed analyses. A new singer sees zeros,
 * never invented numbers. If the server cannot be reached the card quietly hides.
 */
export default function PracticeCard({ refreshKey }) {
  const [data, setData] = useState(null)
  const [saving, setSaving] = useState(false)

  const load = useCallback(() => {
    getWeeklyReport()
      .then(setData)
      .catch(() => setData(null))
  }, [])

  useEffect(() => {
    load()
  }, [load, refreshKey])

  if (!data) return null

  const setGoal = async (goal) => {
    if (goal < 1 || goal > 20 || saving) return
    setSaving(true)
    setData((d) => ({ ...d, daily_goal: goal, goal_met_today: d.today_attempts >= goal }))
    try {
      await updateProfile({ daily_goal: goal })
    } catch {
      load()
    } finally {
      setSaving(false)
    }
  }

  const pct = Math.min(100, Math.round((data.today_attempts / data.daily_goal) * 100))
  const max = Math.max(1, ...data.days.map((d) => d.attempts), data.daily_goal)
  const change = data.score_change
  const quiet = data.attempts === 0 && data.current_streak_days === 0

  return (
    <section aria-label="Your practice" className="nm-card animate-fade-up mt-5 p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="font-serif text-[1.1rem] font-semibold text-brown-900">Your practice</h2>
          <p className="mt-0.5 text-[0.82rem] text-brown-500">
            {quiet ? 'Sing once today to start your streak.' : data.goal_met_today ? 'Goal reached today. Well done.' : `${data.today_attempts} of ${data.daily_goal} today`}
          </p>
        </div>
        <div className="flex items-center gap-1.5 rounded-full bg-blush-100 px-3 py-1.5 text-[0.85rem] font-semibold text-brown-800" title="Days in a row with at least one analysis">
          <Flame className={cn('h-4 w-4', data.current_streak_days > 0 ? 'text-gold-500' : 'text-brown-300')} aria-hidden="true" />
          {data.current_streak_days} <span className="font-normal text-brown-500">{data.current_streak_days === 1 ? 'day' : 'days'}</span>
        </div>
      </div>

      <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-brown-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Today's goal">
        <div className={cn('h-full rounded-full transition-all', data.goal_met_today ? 'bg-sage-500' : 'bg-gold-400')} style={{ width: `${pct}%` }} />
      </div>

      <div className="mt-4 flex items-end justify-between gap-1.5" aria-label="Last 7 days">
        {data.days.map((d) => {
          const dt = new Date(`${d.date}T00:00:00`)
          const met = d.attempts >= data.daily_goal
          return (
            <div key={d.date} className="flex flex-1 flex-col items-center gap-1">
              <div className="flex h-12 w-full items-end justify-center">
                <div
                  className={cn('w-full max-w-[1.6rem] rounded-t-md', d.attempts === 0 ? 'bg-brown-100' : met ? 'bg-sage-500' : 'bg-gold-400')}
                  style={{ height: d.attempts === 0 ? '4px' : `${Math.max(14, (d.attempts / max) * 100)}%` }}
                  title={`${d.attempts} ${d.attempts === 1 ? 'attempt' : 'attempts'}`}
                />
              </div>
              <span className="text-[0.7rem] text-brown-400">{DAY[dt.getDay()]}</span>
            </div>
          )
        })}
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 border-t border-brown-100 pt-3 text-[0.85rem]">
        <div>
          <p className="text-brown-400">This week</p>
          <p className="font-medium text-brown-800">
            {data.attempts} {data.attempts === 1 ? 'attempt' : 'attempts'}
            {data.average_score != null && <span className="font-normal text-brown-500"> · avg {Math.round(data.average_score)}</span>}
          </p>
          {change != null && (
            <p className={cn('mt-0.5 flex items-center gap-1 text-[0.8rem]', change >= 0 ? 'text-sage-600' : 'text-status-warn')}>
              {change >= 0 ? <TrendingUp className="h-3.5 w-3.5" aria-hidden="true" /> : <TrendingDown className="h-3.5 w-3.5" aria-hidden="true" />}
              {change >= 0 ? '+' : ''}{Math.round(change)} vs last week
            </p>
          )}
        </div>
        <div>
          <p className="text-brown-400">Daily goal</p>
          <div className="mt-0.5 flex items-center gap-2">
            <button type="button" aria-label="Lower daily goal" onClick={() => setGoal(data.daily_goal - 1)} className="flex h-7 w-7 items-center justify-center rounded-full border border-brown-200">
              <Minus className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
            <span className="min-w-[2.6rem] text-center font-medium text-brown-800">{data.daily_goal} / day</span>
            <button type="button" aria-label="Raise daily goal" onClick={() => setGoal(data.daily_goal + 1)} className="flex h-7 w-7 items-center justify-center rounded-full border border-brown-200">
              <Plus className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>

      {data.weakest_area && (
        <p className="mt-3 rounded-xl bg-blush-50 px-3 py-2 text-[0.82rem] text-brown-600">
          Focus this week: <b className="text-brown-800">{data.weakest_area.name}</b> (average {Math.round(data.weakest_area.average_score)}).
        </p>
      )}
    </section>
  )
}

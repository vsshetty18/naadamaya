import { useCallback, useState } from 'react'
import { saMidiFrom } from '@/utils/music'

const KEY = 'nm_tools_v1'
const DEFAULTS = { pitchClass: 0, high: false, notation: 'both' } // notation: swara | western | both

function load() {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || 'null')
    if (v && Number.isInteger(v.pitchClass) && v.pitchClass >= 0 && v.pitchClass < 12) {
      return { pitchClass: v.pitchClass, high: !!v.high, notation: ['swara', 'western', 'both'].includes(v.notation) ? v.notation : 'both' }
    }
  } catch {
    /* storage unavailable: use defaults */
  }
  return DEFAULTS
}

/** The singer's Sa and notation choice, remembered on this device (a convenience only). */
export function useTonic() {
  const [state, setState] = useState(load)
  const update = useCallback((patch) => {
    setState((prev) => {
      const next = { ...prev, ...patch }
      try {
        localStorage.setItem(KEY, JSON.stringify(next))
      } catch {
        /* ignore */
      }
      return next
    })
  }, [])
  return { ...state, saMidi: saMidiFrom(state.pitchClass, state.high), update }
}

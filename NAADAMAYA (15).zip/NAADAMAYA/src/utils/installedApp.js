import { useEffect, useState } from 'react'

/**
 * True when NAADAMAYA is running as an installed app (home-screen PWA or the
 * Android APK) instead of in a normal browser tab. Used to hide the "App"
 * tab, which is only useful on the website.
 */
export function isInstalledApp() {
  if (typeof window === 'undefined') return false
  try {
    if (window.matchMedia?.('(display-mode: standalone)').matches) return true
    if (window.matchMedia?.('(display-mode: fullscreen)').matches) return true
    if (window.navigator.standalone === true) return true // iPhone home screen
    if ((document.referrer || '').startsWith('android-app://')) return true // Android APK
  } catch {
    /* ignore */
  }
  return false
}

export function useIsInstalledApp() {
  const [installed, setInstalled] = useState(isInstalledApp)
  useEffect(() => {
    const mq = window.matchMedia?.('(display-mode: standalone)')
    if (!mq) return undefined
    const onChange = () => setInstalled(isInstalledApp())
    mq.addEventListener?.('change', onChange)
    return () => mq.removeEventListener?.('change', onChange)
  }, [])
  return installed
}

/**
 * Music helpers shared by the Tools: note names, swara names, frequency maths.
 * Sa is stored as a MIDI number (the singer's madhya Sa). Swaras are always
 * worked out relative to it, so the same code serves Hindustani, Carnatic
 * (same 12 positions) and Western notation.
 */
export const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
// lowercase = komal (flat), ′ = tivra (sharp Ma)
export const SWARA_NAMES = ['Sa', 're', 'Re', 'ga', 'Ga', 'Ma', 'Ma′', 'Pa', 'dha', 'Dha', 'ni', 'Ni']

export const freqToMidi = (f) => 69 + 12 * Math.log2(f / 440)
export const midiToFreq = (m) => 440 * 2 ** ((m - 69) / 12)

export function noteName(midi) {
  const n = Math.round(midi)
  return `${NOTE_NAMES[((n % 12) + 12) % 12]}${Math.floor(n / 12) - 1}`
}

/** Swara of a MIDI note relative to Sa, with its octave (mandra, madhya or tara). */
export function swaraOf(midi, saMidi) {
  const n = Math.round(midi)
  const d = n - saMidi
  const idx = ((d % 12) + 12) % 12
  const oct = Math.floor(d / 12)
  return { name: SWARA_NAMES[idx], index: idx, octave: oct < 0 ? 'mandra' : oct === 0 ? 'madhya' : 'tara' }
}

/** Valid Sa choices: pitch class 0-11, in the lower or the higher voice register. */
export const saMidiFrom = (pitchClass, high) => 48 + pitchClass + (high ? 12 : 0)

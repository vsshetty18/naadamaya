/**
 * Pitch detection for the tuner (YIN algorithm). Pure function, no browser needed,
 * so it can be tested with generated tones.
 * Returns the frequency in Hz, or null when there is silence or no clear pitch.
 */
export function detectPitch(buf, sampleRate, { minHz = 70, maxHz = 1200, threshold = 0.15 } = {}) {
  const n = buf.length
  let sum = 0
  for (let i = 0; i < n; i++) sum += buf[i] * buf[i]
  if (Math.sqrt(sum / n) < 0.008) return null // too quiet

  const half = Math.floor(n / 2)
  const tauMax = Math.min(half - 1, Math.floor(sampleRate / minHz))
  const tauMin = Math.max(2, Math.floor(sampleRate / maxHz))
  const d = new Float32Array(tauMax + 1)
  for (let tau = 1; tau <= tauMax; tau++) {
    let s = 0
    for (let i = 0; i < half; i++) {
      const x = buf[i] - buf[i + tau]
      s += x * x
    }
    d[tau] = s
  }
  // cumulative mean normalised difference
  const cm = new Float32Array(tauMax + 1)
  cm[0] = 1
  let run = 0
  for (let tau = 1; tau <= tauMax; tau++) {
    run += d[tau]
    cm[tau] = run === 0 ? 1 : (d[tau] * tau) / run
  }
  let tau = -1
  for (let t = tauMin; t <= tauMax; t++) {
    if (cm[t] < threshold) {
      while (t + 1 <= tauMax && cm[t + 1] < cm[t]) t++
      tau = t
      break
    }
  }
  if (tau < 0) return null
  // parabolic refinement
  const a = cm[tau - 1] ?? cm[tau]
  const b = cm[tau]
  const c = cm[tau + 1] ?? cm[tau]
  const denom = a + c - 2 * b
  const shift = denom === 0 ? 0 : (a - c) / (2 * denom)
  return sampleRate / (tau + shift)
}

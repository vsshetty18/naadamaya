export const LEVELS = [
  { value: 'beginner', label: 'Beginner', hint: 'New to singing. Gentle scoring and plain-language tips.' },
  { value: 'intermediate', label: 'Intermediate', hint: 'Sings regularly. Balanced scoring.' },
  { value: 'advanced', label: 'Advanced', hint: 'Trained singer. Stricter scoring and detailed numbers.' },
  { value: 'professional', label: 'Professional', hint: 'Performer or teacher. Studio-grade scoring and full detail.' },
]
export const levelLabel = (v) => LEVELS.find((l) => l.value === v)?.label || null

import { getAudioContext } from '@/audio/engine'

/**
 * Talas and bars. `marks` says what each beat (matra) is:
 *   X = sam (the first beat, strongest)   2,3,4 = tali (clap)   0 = khali (wave, soft)   . = ordinary beat
 */
const m = (len, map) => Array.from({ length: len }, (_, i) => map[i + 1] || '.')
export const TALAS = [
  { id: 'teen', name: 'Teentaal', beats: 16, split: [4, 4, 4, 4], marks: m(16, { 1: 'X', 5: '2', 9: '0', 13: '3' }) },
  { id: 'jhap', name: 'Jhaptaal', beats: 10, split: [2, 3, 2, 3], marks: m(10, { 1: 'X', 3: '2', 6: '0', 8: '3' }) },
  { id: 'ek', name: 'Ektaal', beats: 12, split: [2, 2, 2, 2, 2, 2], marks: m(12, { 1: 'X', 3: '0', 5: '2', 7: '0', 9: '3', 11: '4' }) },
  { id: 'rup', name: 'Rupak', beats: 7, split: [3, 2, 2], marks: m(7, { 1: '0', 4: '2', 6: '3' }) },
  { id: 'dad', name: 'Dadra', beats: 6, split: [3, 3], marks: m(6, { 1: 'X', 4: '0' }) },
  { id: 'keh', name: 'Keherwa', beats: 8, split: [4, 4], marks: m(8, { 1: 'X', 5: '0' }) },
  { id: 'deep', name: 'Deepchandi', beats: 14, split: [3, 4, 3, 4], marks: m(14, { 1: 'X', 4: '2', 8: '0', 11: '3' }) },
  { id: '44', name: '4/4', beats: 4, split: [4], marks: m(4, { 1: 'X' }) },
  { id: '34', name: '3/4', beats: 3, split: [3], marks: m(3, { 1: 'X' }) },
  { id: '68', name: '6/8', beats: 6, split: [3, 3], marks: m(6, { 1: 'X', 4: '2' }) },
]

const SOUND = {
  X: { f: 1500, v: 0.9, d: 0.09 }, // sam
  2: { f: 1000, v: 0.6, d: 0.07 }, // tali
  3: { f: 1000, v: 0.6, d: 0.07 },
  4: { f: 1000, v: 0.6, d: 0.07 },
  0: { f: 520, v: 0.4, d: 0.06 }, // khali: softer and lower
  '.': { f: 760, v: 0.22, d: 0.04 },
}

export class TalaClock {
  constructor(onBeat) {
    this.onBeat = onBeat
    this.tala = TALAS[0]
    this.bpm = 80
    this.running = false
    this.timer = null
  }

  configure({ tala, bpm }) {
    if (tala) this.tala = tala
    if (bpm) this.bpm = bpm
  }

  start() {
    if (this.running) return
    const ctx = getAudioContext()
    if (!ctx) return
    this.ctx = ctx
    this.running = true
    this.index = 0
    this.next = ctx.currentTime + 0.08
    this.timer = setInterval(() => this.schedule(), 25)
    this.schedule()
  }

  schedule() {
    while (this.next < this.ctx.currentTime + 0.12) {
      const at = this.next
      const i = this.index % this.tala.beats
      this.click(this.tala.marks[i], at)
      const wait = Math.max(0, (at - this.ctx.currentTime) * 1000)
      setTimeout(() => this.running && this.onBeat(i), wait)
      this.index += 1
      this.next += 60 / this.bpm
    }
  }

  click(mark, t) {
    const s = SOUND[mark] || SOUND['.']
    const o = this.ctx.createOscillator()
    const g = this.ctx.createGain()
    o.type = 'square'
    o.frequency.value = s.f
    g.gain.setValueAtTime(s.v * 0.3, t)
    g.gain.exponentialRampToValueAtTime(0.0001, t + s.d)
    o.connect(g).connect(this.ctx.destination)
    o.start(t)
    o.stop(t + s.d + 0.02)
  }

  stop() {
    this.running = false
    clearInterval(this.timer)
  }
}

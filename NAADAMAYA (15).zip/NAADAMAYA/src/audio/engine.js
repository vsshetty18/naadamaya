/** One shared audio context for all the tools. Browsers allow only a few, and it must start from a tap. */
let ctx = null
export function getAudioContext() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext
    if (!AC) return null
    ctx = new AC()
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {})
  return ctx
}

/** One short note (used by the swara ear-training buttons). */
export function playTone(freq, seconds = 1.4, volume = 0.25) {
  const c = getAudioContext()
  if (!c) return
  const t = c.currentTime
  const out = c.createGain()
  out.gain.setValueAtTime(0, t)
  out.gain.linearRampToValueAtTime(volume, t + 0.03)
  out.gain.exponentialRampToValueAtTime(0.0001, t + seconds)
  out.connect(c.destination)
  ;[1, 2, 3].forEach((h, i) => {
    const o = c.createOscillator()
    const g = c.createGain()
    o.type = 'sine'
    o.frequency.value = freq * h
    g.gain.value = [1, 0.35, 0.12][i]
    o.connect(g).connect(out)
    o.start(t)
    o.stop(t + seconds + 0.05)
  })
}

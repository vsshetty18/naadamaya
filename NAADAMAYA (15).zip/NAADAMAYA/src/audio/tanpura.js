import { getAudioContext } from '@/audio/engine'
import { midiToFreq } from '@/utils/music'

/**
 * A tanpura built from sound waves (no recordings). Four strings are plucked in turn:
 * Pa (or Ma/Ni), Sa, Sa, then the low Sa. Each pluck is a bright, buzzing tone that
 * fades slowly, so the strings overlap and shimmer like the real instrument.
 */
const HARMONICS = (() => {
  const real = new Float32Array(26)
  const imag = new Float32Array(26)
  for (let n = 1; n < 26; n++) imag[n] = (1 / n ** 0.85) * (n >= 4 && n <= 9 ? 1.5 : 1) // the "jawari" buzz
  return { real, imag }
})()

export const STRING_CHOICES = [
  { id: 7, label: 'Pa' },
  { id: 5, label: 'Ma' },
  { id: 11, label: 'Ni' },
]
export const SPEEDS = [
  { id: 'slow', label: 'Slow', gap: 1.8 },
  { id: 'medium', label: 'Medium', gap: 1.4 },
  { id: 'fast', label: 'Fast', gap: 1.05 },
]

export class Tanpura {
  constructor() {
    this.ctx = null
    this.timer = null
    this.nextTime = 0
    this.step = 0
    this.saMidi = 48
    this.fifth = 7
    this.gap = 1.4
    this.master = null
    this.volume = 0.6
    this.running = false
  }

  configure({ saMidi, fifth, gap, volume }) {
    if (saMidi != null) this.saMidi = saMidi
    if (fifth != null) this.fifth = fifth
    if (gap != null) this.gap = gap
    if (volume != null) {
      this.volume = volume
      if (this.master) this.master.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.05)
    }
  }

  start() {
    if (this.running) return
    const ctx = getAudioContext()
    if (!ctx) return
    this.ctx = ctx
    this.master = ctx.createGain()
    this.master.gain.value = 0
    const comp = ctx.createDynamicsCompressor()
    this.master.connect(comp).connect(ctx.destination)
    this.master.gain.setTargetAtTime(this.volume, ctx.currentTime, 0.3)
    this.wave = ctx.createPeriodicWave(HARMONICS.real, HARMONICS.imag)
    this.running = true
    this.step = 0
    this.nextTime = ctx.currentTime + 0.1
    this.timer = setInterval(() => this.schedule(), 100)
    this.schedule()
  }

  schedule() {
    while (this.nextTime < this.ctx.currentTime + 0.35) {
      this.pluck(this.step % 4, this.nextTime)
      this.step += 1
      this.nextTime += this.gap
    }
  }

  pluck(which, t) {
    const ctx = this.ctx
    const midi = [this.saMidi - 12 + this.fifth, this.saMidi, this.saMidi, this.saMidi - 12][which]
    const f = midiToFreq(midi)
    const lp = ctx.createBiquadFilter()
    lp.type = 'lowpass'
    lp.frequency.setValueAtTime(4200, t)
    lp.frequency.exponentialRampToValueAtTime(900, t + 3.5)
    const env = ctx.createGain()
    env.gain.setValueAtTime(0, t)
    env.gain.linearRampToValueAtTime(0.16, t + 0.02)
    env.gain.exponentialRampToValueAtTime(0.0001, t + 5.5)
    lp.connect(env).connect(this.master)
    ;[0, 3].forEach((cents) => {
      const o = ctx.createOscillator()
      o.setPeriodicWave(this.wave)
      o.frequency.value = f
      o.detune.value = cents
      o.connect(lp)
      o.start(t)
      o.stop(t + 5.6)
    })
  }

  stop() {
    if (!this.running) return
    this.running = false
    clearInterval(this.timer)
    const now = this.ctx.currentTime
    this.master.gain.cancelScheduledValues(now)
    this.master.gain.setTargetAtTime(0, now, 0.15)
    const m = this.master
    setTimeout(() => m.disconnect(), 800)
  }
}

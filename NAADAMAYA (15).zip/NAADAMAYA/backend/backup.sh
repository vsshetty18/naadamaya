#!/usr/bin/env bash
# NAADAMAYA backup and housekeeping.
#
#   bash ~/NAADAMAYA/backend/backup.sh                  back up the database now
#   bash ~/NAADAMAYA/backend/backup.sh --install-cron   do it every night (safe to repeat)
#   bash ~/NAADAMAYA/backend/backup.sh --list           show saved backups
#
# Backups go to ~/naadamaya-backups, one file per day, and the last 14 days are kept.
set -euo pipefail
BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT_DIR="$HOME/naadamaya-backups"
COMPOSE=(docker compose -f "$BACKEND_DIR/docker-compose.prod.yml")
mkdir -p "$OUT_DIR"

case "${1:-}" in
  --list) ls -lh "$OUT_DIR"; exit 0 ;;
  --install-cron)
    SELF="$BACKEND_DIR/backup.sh"
    TMP="$(mktemp)"
    crontab -l 2>/dev/null | grep -v "naadamaya-nightly" > "$TMP" || true
    echo "30 2 * * * bash $SELF >> $HOME/naadamaya-backups/backup.log 2>&1   # naadamaya-nightly" >> "$TMP"
    echo "30 3 * * * cd $BACKEND_DIR && docker compose -f docker-compose.prod.yml exec -T api python -m app.workers.maintenance >> $HOME/naadamaya-backups/maintenance.log 2>&1   # naadamaya-nightly" >> "$TMP"
    crontab "$TMP"; rm -f "$TMP"
    echo "Nightly backup (2:30 am) and cleanup (3:30 am) are scheduled."
    exit 0 ;;
esac

cd "$BACKEND_DIR"
FILE="$OUT_DIR/naadamaya-$(date +%Y-%m-%d_%H%M).sql.gz"
"${COMPOSE[@]}" exec -T db pg_dump -U naadamaya -d naadamaya --no-owner | gzip > "$FILE"
[ -s "$FILE" ] || { rm -f "$FILE"; echo "Backup FAILED (empty file)"; exit 1; }
find "$OUT_DIR" -name 'naadamaya-*.sql.gz' -mtime +14 -delete
echo "$(date '+%F %T') backup saved: $FILE ($(du -h "$FILE" | cut -f1))"

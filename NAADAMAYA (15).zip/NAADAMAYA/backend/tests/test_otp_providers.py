"""Fast2SMS provider: builds the right request and never accepts a rejected send."""
import io
import json
import urllib.error

import pytest

from app.core.config import settings
from app.core.exceptions import ServiceUnavailableError
from app.services.otp import providers


class _Resp(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


def _provider(monkeypatch):
    monkeypatch.setattr(settings, "fast2sms_api_key", "test-key")
    return providers.Fast2SmsOtpProvider()


def test_fast2sms_requires_key(monkeypatch):
    monkeypatch.setattr(settings, "fast2sms_api_key", "")
    with pytest.raises(ServiceUnavailableError):
        providers.Fast2SmsOtpProvider()


def test_fast2sms_sends_ten_digit_number_and_header(monkeypatch):
    seen = {}

    def fake_open(req, timeout=0):
        seen["url"] = req.full_url
        seen["auth"] = req.get_header("Authorization")
        return _Resp(json.dumps({"return": True}).encode())

    monkeypatch.setattr(providers.urllib.request, "urlopen", fake_open)
    _provider(monkeypatch).send("+919876543210", "482913")
    assert "numbers=9876543210" in seen["url"]
    assert "route=q" in seen["url"]
    assert "482913" in seen["url"]
    assert "NAADAMAYA" in seen["url"]
    assert seen["auth"] == "test-key"


def test_fast2sms_rejected_send_raises(monkeypatch):
    monkeypatch.setattr(
        providers.urllib.request,
        "urlopen",
        lambda req, timeout=0: _Resp(json.dumps({"return": False, "message": "no"}).encode()),
    )
    with pytest.raises(ServiceUnavailableError):
        _provider(monkeypatch).send("+919876543210", "111111")


def test_fast2sms_http_error_raises(monkeypatch):
    def boom(req, timeout=0):
        raise urllib.error.HTTPError(req.full_url, 412, "x", {}, None)

    monkeypatch.setattr(providers.urllib.request, "urlopen", boom)
    with pytest.raises(ServiceUnavailableError):
        _provider(monkeypatch).send("+919876543210", "111111")


def test_factory_returns_fast2sms(monkeypatch):
    monkeypatch.setattr(settings, "otp_provider", "fast2sms")
    monkeypatch.setattr(settings, "fast2sms_api_key", "k")
    providers.get_otp_provider.cache_clear()
    try:
        assert providers.get_otp_provider().name == "fast2sms"
    finally:
        providers.get_otp_provider.cache_clear()

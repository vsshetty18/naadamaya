"""Daily goal and the weekly report."""

from datetime import timedelta

from app.core.security import utcnow
from app.models.analysis import Analysis
from tests.test_credits_and_analysis import run_worker, start


def _do_attempts(client, user, upload_song, upload_recording, monkeypatch, n):
    monkeypatch.setattr("time.sleep", lambda s: None)
    song = upload_song(user)
    ids = []
    for _ in range(n):
        rec = upload_recording(user, song["id"])
        aid = start(client, user, rec["id"]).json()["analysis_id"]
        run_worker(aid)
        ids.append(aid)
    return ids


def test_new_user_gets_zeros_and_default_goal(client, user_a):
    r = client.get("/api/v1/progress/weekly", headers=user_a.headers).json()
    assert r["attempts"] == 0 and r["average_score"] is None and r["current_streak_days"] == 0
    assert r["daily_goal"] == 1 and r["goal_met_today"] is False and len(r["days"]) == 7


def test_goal_can_be_set_and_is_validated(client, user_a):
    ok = client.put("/api/v1/profile", json={"daily_goal": 3}, headers=user_a.headers)
    assert ok.status_code == 200 and ok.json()["daily_goal"] == 3
    for bad in (0, 21, -1):
        assert client.put("/api/v1/profile", json={"daily_goal": bad}, headers=user_a.headers).status_code == 422
    # sending null leaves the goal alone
    client.put("/api/v1/profile", json={"daily_goal": None}, headers=user_a.headers)
    assert client.get("/api/v1/profile", headers=user_a.headers).json()["daily_goal"] == 3


def test_weekly_counts_attempts_and_goal(client, user_a, upload_song, upload_recording, monkeypatch):
    _do_attempts(client, user_a, upload_song, upload_recording, monkeypatch, 2)
    r = client.get("/api/v1/progress/weekly?tz=UTC", headers=user_a.headers).json()
    assert r["attempts"] == 2 and r["practice_days"] == 1 and r["today_attempts"] == 2
    assert r["goal_met_today"] is True and r["goal_days_met"] == 1
    assert r["current_streak_days"] == 1 and r["days"][-1]["attempts"] == 2
    client.put("/api/v1/profile", json={"daily_goal": 5}, headers=user_a.headers)
    r = client.get("/api/v1/progress/weekly?tz=UTC", headers=user_a.headers).json()
    assert r["goal_met_today"] is False and r["daily_goal"] == 5


def test_weekly_compares_with_previous_week_and_uses_time_zone(client, db, user_a, upload_song, upload_recording, monkeypatch):
    ids = _do_attempts(client, user_a, upload_song, upload_recording, monkeypatch, 2)
    old = db.get(Analysis, ids[0])
    old.completed_at = utcnow() - timedelta(days=9)
    db.commit()
    r = client.get("/api/v1/progress/weekly?tz=UTC", headers=user_a.headers).json()
    assert r["attempts"] == 1 and r["previous_attempts"] == 1
    assert r["score_change"] is not None
    assert r["current_streak_days"] == 1  # the 9-day-old attempt does not extend it
    # an unknown time zone never errors
    assert client.get("/api/v1/progress/weekly?tz=Not/AZone", headers=user_a.headers).status_code == 200
    # one user never sees another's week
    assert client.get("/api/v1/progress/weekly").status_code == 401

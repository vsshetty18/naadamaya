"""Singing levels: same measurements, level-appropriate bar. Intermediate must equal the original scoring."""

import numpy as np

from app.analyzers.feedback_engine import RuleBasedFeedback
from app.analyzers.interfaces import PITCH_ACCURACY, RHYTHM, STABILITY, Finding, MetricResult
from app.analyzers.levels import LEVELS, profile_for
from app.analyzers.pitch_analyzer import SignalPitchAnalyzer
from app.analyzers.stability_analyzer import SignalStabilityAnalyzer
from tests.test_analyzers import (
    REF_HZ, SEMIS, aligned_from, inputs_with, note_track, stability_inputs,
)


def test_unknown_or_missing_level_is_intermediate():
    for v in (None, "", "expert", "BEGINNER ", "Advanced"):
        assert profile_for(v).name in LEVELS
    assert profile_for(None).name == "intermediate"
    assert profile_for("nonsense").name == "intermediate"
    assert profile_for(" Advanced ").name == "advanced"


def test_intermediate_keeps_the_original_numbers():
    p = profile_for("intermediate")
    assert (p.pitch_best, p.pitch_worst, p.on_pitch, p.sharp_flat, p.unstable_std) == (10, 100, 25, 35, 45)
    assert (p.lag_best, p.lag_worst, p.flag_lag) == (0.08, 0.60, 0.15)
    assert (p.spread_best, p.spread_worst, p.unsteady) == (15, 70, 40)


def test_bars_get_stricter_with_level():
    order = [profile_for(n) for n in ("beginner", "intermediate", "advanced", "professional")]
    for a, b in zip(order, order[1:]):
        assert a.pitch_worst > b.pitch_worst and a.on_pitch > b.on_pitch
        assert a.lag_worst > b.lag_worst and a.spread_worst > b.spread_worst


def _pitch_score(level, cents):
    user_hz = REF_HZ * 2.0 ** (cents / 1200.0)
    ins = inputs_with(aligned=aligned_from(REF_HZ, user_hz))
    ins.level = level
    out = SignalPitchAnalyzer().analyze(ins)
    assert out.metric.available
    return out.metric.score


def test_same_singing_scores_by_level():
    s = {lv: _pitch_score(lv, 40) for lv in ("beginner", "intermediate", "advanced", "professional")}
    assert s["beginner"] > s["intermediate"] > s["advanced"] > s["professional"]
    assert _pitch_score(None, 40) == s["intermediate"]  # no level chosen = original behaviour


def test_perfect_singing_is_perfect_at_every_level():
    for lv in LEVELS:
        assert _pitch_score(lv, 0) > 98


def test_wobbly_notes_are_judged_by_level():
    scores = {}
    for lv in ("beginner", "professional"):
        ins = stability_inputs(note_track([220, 262, 330, 262], noise_cents=25))
        ins.level = lv
        out = SignalStabilityAnalyzer().analyze(ins)
        assert out.metric.available
        scores[lv] = out.metric.score
    assert scores["beginner"] > scores["professional"]


def _feedback(level):
    f = [
        Finding("pitch_sharp", PITCH_ACCURACY, 10, 15, 0.9, {"cents": 80}, "Sharp"),
        Finding("late_entry", RHYTHM, 20, 25, 0.7, {"offset_ms": 300}, "Late"),
        Finding("unstable_note", STABILITY, 30, 33, 0.6, {"spread_cents": 55}, "Wobble"),
        Finding("pitch_flat", PITCH_ACCURACY, 40, 45, 0.5, {"cents": 60}, "Flat"),
        Finding("pitch_unstable", PITCH_ACCURACY, 50, 55, 0.4, {"std_cents": 50}, "Unsteady"),
    ]
    metrics = [MetricResult.measured(PITCH_ACCURACY, 55), MetricResult.measured(RHYTHM, 50), MetricResult.measured(STABILITY, 45)]
    return RuleBasedFeedback().generate(metrics, f, {"level": level})


def test_beginner_feedback_is_plain_and_short():
    out = _feedback("beginner")
    text = " ".join(i["description"] or "" for i in out["insights"] if i["type"] == "improvement")
    assert "cents" not in text and " ms " not in text
    assert len([i for i in out["insights"] if i["type"] == "improvement"]) <= 2
    assert len(out["recommendations"]) <= 2


def test_advanced_feedback_has_numbers_and_drills():
    out = _feedback("professional")
    text = " ".join(i["description"] or "" for i in out["insights"] if i["type"] == "improvement")
    assert "cents" in text
    assert len([i for i in out["insights"] if i["type"] == "improvement"]) >= 5
    assert any("Tuner" in r["description"] or "tala" in r["description"] or "drone" in r["description"] for r in out["recommendations"])


def test_default_level_feedback_unchanged():
    a, b = _feedback(None), _feedback("intermediate")
    assert a == b

"""
Singing levels. The SAME measurements are judged against a level-appropriate bar,
so a beginner is not told they are failing for being a little off, and a
professional is held to a studio-grade standard.

"Intermediate" is exactly the original scoring, so nothing changes for people
who never pick a level. The report always says which level it was scored for.

Pitch/stability numbers are in cents (100 = one semitone), timing in seconds.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class LevelProfile:
    name: str
    label: str
    # pitch
    pitch_best: float      # median error at or below this scores 100
    pitch_worst: float     # at or above this scores 0
    on_pitch: float        # counts as "matched"
    sharp_flat: float      # a stretch must average beyond this to be flagged
    unstable_std: float
    # rhythm
    lag_best: float
    lag_worst: float
    flag_lag: float
    # held notes
    spread_best: float
    spread_worst: float
    unsteady: float
    # feedback style
    plain_words: bool      # no cents or milliseconds in the wording
    max_improvements: int
    max_tips: int
    drills: bool           # extra technical practice drills


LEVELS: dict[str, LevelProfile] = {
    "beginner": LevelProfile(
        "beginner", "Beginner", 20, 150, 40, 55, 65, 0.15, 0.90, 0.30, 25, 100, 60,
        plain_words=True, max_improvements=2, max_tips=2, drills=False,
    ),
    "intermediate": LevelProfile(  # the original numbers
        "intermediate", "Intermediate", 10, 100, 25, 35, 45, 0.08, 0.60, 0.15, 15, 70, 40,
        plain_words=False, max_improvements=6, max_tips=4, drills=False,
    ),
    "advanced": LevelProfile(
        "advanced", "Advanced", 7, 70, 18, 25, 32, 0.06, 0.40, 0.10, 11, 50, 30,
        plain_words=False, max_improvements=5, max_tips=4, drills=True,
    ),
    "professional": LevelProfile(
        "professional", "Professional", 5, 45, 12, 18, 25, 0.04, 0.28, 0.07, 8, 35, 22,
        plain_words=False, max_improvements=6, max_tips=5, drills=True,
    ),
}
DEFAULT_LEVEL = "intermediate"


def profile_for(level: str | None) -> LevelProfile:
    return LEVELS.get((level or "").strip().lower(), LEVELS[DEFAULT_LEVEL])

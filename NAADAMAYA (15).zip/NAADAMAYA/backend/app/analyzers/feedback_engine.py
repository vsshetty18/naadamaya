"""
NAADAMAYA feedback engine.

    feedback = RuleBasedFeedback().generate(metrics, findings, context)

Turns MEASURED facts into plain-language insights, "How You Performed" lines
and practice recommendations. Rule-based today (FeedbackGenerator interface),
so an AI teacher can replace it later.

Rules:
  - Every sentence is built from a Finding (what, where, how big) or a
    measured MetricResult. No generic motivation, no random text.
  - Each insight carries `evidence`: the numbers and time range it came from.
  - A positive insight appears only when its metric was measured AND strong.
  - Recommendations target the weakest measured areas and the worst findings.
  - If nothing was measured well enough, the output is empty. It never
    pretends.

Returned dict:
  insights         [{type, title, description, priority, evidence}]
  performance      [{type, text}]       ("How You Performed")
  recommendations  [{title, description, priority, metric_type,
                     section_key, duration_minutes}]
"""

from typing import Any

from app.analyzers.interfaces import (
    BREATH_CONTROL,
    EXPRESSION,
    MELODY_MATCHING,
    PITCH_ACCURACY,
    RHYTHM,
    STABILITY,
    FeedbackGenerator,
    Finding,
    MetricResult,
)
from app.analyzers.levels import profile_for
from app.utils.audio_utils import format_duration

STRONG = 80.0
WEAK = 70.0
MAX_INSIGHTS_PER_KIND = 4
MAX_RECOMMENDATIONS = 4


def _when(f: Finding) -> str:
    return f"{format_duration(f.start)} to {format_duration(f.end)}"


def _sentence(f: Finding) -> tuple[str, str]:
    """(title, description) for one finding, using only its measured evidence."""
    e, when = f.evidence, _when(f)

    if f.kind == "pitch_sharp":
        return ("Pitch runs sharp", f"From {when} you were about {abs(e.get('cents', 0))} cents above the original. "
                "Practise the phrase slowly and listen for the target note before adding speed.")
    if f.kind == "pitch_flat":
        return ("Pitch runs flat", f"From {when} you were about {abs(e.get('cents', 0))} cents below the original. "
                "Hold the phrase slowly and match the target pitch before increasing tempo.")
    if f.kind == "pitch_unstable":
        return ("Pitch is unsteady", f"From {when} your pitch moved around by about {e.get('std_cents', 0):.0f} cents.")
    if f.kind == "melody_mismatch":
        return ("Melody differs from the original",
                f"From {when} your melody moved about {e.get('mean_gap_semitones', 0):.1f} semitones away from the original's.")
    if f.kind == "late_entry":
        return ("Entries are late", f"From {when} you came in about {abs(e.get('offset_ms', 0))} ms after the original.")
    if f.kind == "early_entry":
        return ("Entries are early", f"From {when} you came in about {abs(e.get('offset_ms', 0))} ms before the original.")
    if f.kind == "tempo_drift":
        way = "slowed down" if e.get("direction") == "slowing" else "sped up"
        return ("Tempo drifts", f"Across the song you {way}, ending about {abs(e.get('drift_seconds', 0)):.1f} seconds off the original's pace.")
    if f.kind == "tempo_off":
        way = "slower" if e.get("direction") == "slower" else "faster"
        return ("Tempo differs", f"You sang about {abs(e.get('tempo_ratio', 1) - 1) * 100:.0f}% {way} than the original.")
    if f.kind == "unstable_note":
        high = " in your higher notes" if e.get("high_note") else ""
        return ("Held notes waver" + high, f"Around {when} held notes wavered by about {e.get('spread_cents', 0)} cents.")
    if f.kind == "energy_flat":
        return ("Dynamics are flat", f"From {when} the original varies in loudness by about {e.get('reference_variation_db', 0):.0f} dB; you varied by about {e.get('user_variation_db', 0):.0f} dB.")
    if f.kind == "breath_strained":
        return ("Phrase end weakens", f"The phrase at {when} ({e.get('phrase_seconds', 0):.0f} s) faded or sagged toward the end.")
    return (f.label or "Needs attention", f"Around {when}.")


def _plain_sentence(f: Finding) -> tuple[str, str] | None:
    """Beginner wording: no cents, no milliseconds. Same facts, simpler words."""
    e, when = f.evidence, _when(f)
    size = abs(e.get("cents", 0))
    how = "a little" if size < 50 else "clearly" if size < 120 else "a lot"
    if f.kind == "pitch_sharp":
        return ("You sang a bit high", f"From {when} you sang {how} higher than the original. Slow down and listen for the note before you sing it.")
    if f.kind == "pitch_flat":
        return ("You sang a bit low", f"From {when} you sang {how} lower than the original. Hum the note first, then add the words.")
    if f.kind == "pitch_unstable":
        return ("Your voice wobbled", f"From {when} your note moved around. Try holding it still, like a straight line.")
    if f.kind == "late_entry":
        return ("You started late", f"Around {when} you started a little after the original. Listen for the first beat and join in with it.")
    if f.kind == "early_entry":
        return ("You started early", f"Around {when} you started a little before the original. Wait for the cue, then begin.")
    if f.kind == "tempo_drift":
        return ("Your speed changed", "Across the song your speed slowly changed. Tap your foot to a steady beat while you sing.")
    if f.kind == "tempo_off":
        return ("Your speed differs", "You sang at a different speed from the original. Practise with the original playing softly.")
    if f.kind == "unstable_note":
        return ("Long notes wobbled", f"Around {when} a held note wobbled. Breathe out slowly and keep it steady.")
    return None


ADVANCED_DRILLS = {
    PITCH_ACCURACY: "Record the flagged phrase on a tanpura and check each note in the Tuner. Aim for every note within the tolerance shown in the numbers.",
    MELODY_MATCHING: "Sing the phrase as swaras first (no words), then with the lyrics, keeping the same ornament shapes.",
    RHYTHM: "Sing the phrase against a tala keeper at the original's tempo, then at 110% and 90%, landing every sam together.",
    STABILITY: "Sustain each long note for 8 seconds against the drone. Compare a straight tone with your natural vibrato.",
    EXPRESSION: "Map the original's loudness phrase by phrase, then rehearse your crescendos and decrescendos separately.",
    BREATH_CONTROL: "Rehearse the longest phrase with a planned breath point, keeping the final note as full as the first.",
}

RECOMMENDATION_TEXT = {
    PITCH_ACCURACY: ("Match the target pitch", "Sing the flagged phrases slowly alongside the original, then record again.", 8),
    MELODY_MATCHING: ("Follow the melody's shape", "Hum the original's line first, then sing it with words.", 8),
    RHYTHM: ("Tighten your timing", "Sing along at about 80% tempo and aim to start each line together with the original.", 8),
    STABILITY: ("Steady your held notes", "Hold long notes against a steady drone and keep them still.", 10),
    EXPRESSION: ("Shape your dynamics", "Mark where the original gets louder and softer, and follow that shape.", 6),
    BREATH_CONTROL: ("Support the end of phrases", "Practise the longest phrases on one breath at a slower pace, keeping the last note as firm as the first.", 8),
}


class RuleBasedFeedback(FeedbackGenerator):
    def generate(
        self,
        metrics: list[MetricResult],
        findings: list[Finding],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        lv = profile_for((context or {}).get("level"))
        measured = [m for m in metrics if m.available and m.score is not None]
        if not measured:
            return {"insights": [], "performance": [], "recommendations": []}

        insights: list[dict] = []
        performance: list[dict] = []

        # ---- strengths: only strong, measured metrics ----
        for m in sorted(measured, key=lambda m: -m.score)[:MAX_INSIGHTS_PER_KIND]:
            if m.score >= STRONG:
                insights.append({
                    "type": "positive",
                    "title": f"{m.name} is strong",
                    "description": m.description,
                    "priority": 0,
                    "evidence": {"metric": m.metric_id, "score": m.score, **m.evidence},
                })
                performance.append({"type": "positive", "text": m.description or f"{m.name} matched the original well."})

        # ---- improvements: worst findings first ----
        ranked = sorted(findings, key=lambda f: -f.severity)[: lv.max_improvements]
        for i, f in enumerate(ranked, start=1):
            title, desc = (_plain_sentence(f) if lv.plain_words else None) or _sentence(f)
            insights.append({
                "type": "improvement",
                "title": title,
                "description": desc,
                "priority": i,
                "evidence": {"kind": f.kind, "metric": f.metric_id, "start": f.start, "end": f.end, **f.evidence},
            })
            performance.append({"type": "issue" if f.severity >= 0.6 else "improvement", "text": desc})

        # weak metrics with no specific finding still deserve a note
        covered = {f.metric_id for f in ranked}
        for m in measured:
            if lv.plain_words and sum(1 for i in insights if i["type"] == "improvement") >= lv.max_improvements:
                break
            if m.score < WEAK and m.metric_id not in covered:
                insights.append({
                    "type": "improvement",
                    "title": f"{m.name} needs work",
                    "description": f"{m.name} needs a little more practice." if lv.plain_words else m.description,
                    "priority": len(insights) + 1,
                    "evidence": {"metric": m.metric_id, "score": m.score, **m.evidence},
                })

        # ---- recommendations: weakest measured metrics ----
        recommendations: list[dict] = []
        for m in sorted(measured, key=lambda m: m.score):
            if m.score >= STRONG or m.metric_id not in RECOMMENDATION_TEXT:
                continue
            title, desc, minutes = RECOMMENDATION_TEXT[m.metric_id]
            if lv.drills and m.metric_id in ADVANCED_DRILLS:
                desc = ADVANCED_DRILLS[m.metric_id]
                minutes += 4
            worst = max((f for f in findings if f.metric_id == m.metric_id), key=lambda f: f.severity, default=None)
            if worst is not None:
                desc = f"{desc} Start with {_when(worst)}."
            recommendations.append({
                "title": title,
                "description": desc,
                "priority": len(recommendations) + 1,
                "metric_type": m.metric_id,
                "section_key": None,
                "duration_minutes": minutes,
                "start": worst.start if worst else None,
            })
            if len(recommendations) >= lv.max_tips:
                break

        return {"insights": insights, "performance": performance, "recommendations": recommendations}

"""
NAADAMAYA housekeeping. Run once a day (the deploy script sets this up):

    python -m app.workers.maintenance

It frees disk space so the server never fills up:
  1. Audio of recordings you deleted more than 7 days ago.
  2. Audio of recordings older than AUDIO_RETENTION_DAYS (default 90).
     The score, report and history stay. Only the audio files go.
Songs are not touched by rule 2, because a song can be practised again later.
It works in small batches and is safe to run again at any time.
"""

from datetime import timedelta

from sqlalchemy import or_, select

from app.core.config import settings
from app.core.database import session_scope
from app.core.logging import get_logger, setup_logging
from app.core.security import utcnow
from app.models.recording import Recording
from app.services.storage.storage_service import delete_quietly

log = get_logger("naadamaya.maintenance")
BATCH = 500
HAS_FILE = or_(Recording.original_file_key.is_not(None), Recording.processed_file_key.is_not(None))


def _purge(db, rows) -> int:
    for rec in rows:
        delete_quietly(rec.original_file_key, rec.processed_file_key)
        rec.original_file_key = None
        rec.processed_file_key = None
    return len(rows)


def run() -> dict:
    now = utcnow()
    result = {"deleted_recordings": 0, "expired_recordings": 0}

    with session_scope() as db:
        rows = db.scalars(
            select(Recording)
            .where(Recording.is_deleted.is_(True), Recording.deleted_at < now - timedelta(days=7), HAS_FILE)
            .limit(BATCH)
        ).all()
        result["deleted_recordings"] = _purge(db, rows)

    if settings.audio_retention_days > 0:
        cutoff = now - timedelta(days=settings.audio_retention_days)
        with session_scope() as db:
            rows = db.scalars(
                select(Recording).where(Recording.created_at < cutoff, HAS_FILE).limit(BATCH)
            ).all()
            result["expired_recordings"] = _purge(db, rows)

    log.info("maintenance finished: %s", result)
    return result


if __name__ == "__main__":
    setup_logging()
    print(run())

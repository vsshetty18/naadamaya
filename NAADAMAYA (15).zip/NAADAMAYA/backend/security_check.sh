#!/usr/bin/env bash
# NAADAMAYA security check. Safe to run any time: it only READS, it changes nothing.
#   bash ~/NAADAMAYA/backend/security_check.sh
set -uo pipefail
BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$BACKEND_DIR"
COMPOSE=(docker compose -f docker-compose.prod.yml)
APP_HOST="${APP_HOST:-app.naadamaya.site}"
pass=0; warn=0; fail=0
ok()   { echo "  PASS  $1"; pass=$((pass+1)); }
bad()  { echo "  WARN  $1"; echo "        -> $2"; warn=$((warn+1)); }
crit() { echo "  FAIL  $1"; echo "        -> $2"; fail=$((fail+1)); }
envval() { grep -E "^$1=" .env 2>/dev/null | tail -n1 | cut -d= -f2-; }

echo "NAADAMAYA security check"; echo

echo "1. Secrets file"
[ -f .env ] || crit ".env is missing" "run deploy.sh"
perm=$(stat -c %a .env 2>/dev/null || echo 000)
[ "$perm" = "600" ] && ok ".env is readable only by you (600)" || crit ".env permissions are $perm" "run: chmod 600 $BACKEND_DIR/.env"
for k in JWT_SECRET TOKEN_HASH_SECRET; do
  v=$(envval $k); [ "${#v}" -ge 32 ] && ok "$k is long enough (${#v} characters)" || crit "$k is too short" "set a random value of 32+ characters"
done
[ "$(envval JWT_SECRET)" != "$(envval TOKEN_HASH_SECRET)" ] && ok "the two secrets are different" || crit "JWT_SECRET equals TOKEN_HASH_SECRET" "make them different"

echo; echo "2. Mode"
env_=$(envval ENVIRONMENT)
if [ "$env_" = "production" ]; then ok "ENVIRONMENT=production"; else bad "ENVIRONMENT is '$env_'" "after this check shows no FAIL, switch with:  sed -i 's/^ENVIRONMENT=.*/ENVIRONMENT=production/' $BACKEND_DIR/.env  then redeploy"; fi
[ "$(envval OTP_MODE)" = "production" ] && ok "OTP_MODE=production (real SMS only)" || crit "OTP_MODE is not production" "set OTP_MODE=production, otherwise a fixed test code may work"
[ "$(envval DEBUG)" = "true" ] && crit "DEBUG is on" "set DEBUG=false" || ok "DEBUG is off"
case "$(envval CORS_ORIGINS)" in *'*'*|"") crit "CORS_ORIGINS is open" "list only https://$APP_HOST";; *) ok "CORS lists exact sites only";; esac

echo; echo "3. Would production mode start? (dry run, the live app is not touched)"
out=$("${COMPOSE[@]}" run --rm --no-deps -T -e ENVIRONMENT=production api python -c "import app.core.config" 2>&1 | tail -3)
if echo "$out" | grep -q "Unsafe production configuration"; then crit "production mode would refuse to start" "$(echo "$out" | grep -o 'Unsafe production configuration.*' | head -c 300)"; else ok "all production safety rules pass"; fi

echo; echo "4. Open doors on this server"
exposed=$(ss -tlnH 2>/dev/null | awk '{print $4}' | grep -vE '^(127\.|\[::1\])' | sed 's/.*://' | sort -un | grep -vE '^(22|80|443|53)$' | tr '\n' ' ')
[ -z "${exposed// /}" ] && ok "only SSH (22), HTTP (80) and HTTPS (443) listen publicly" || bad "extra public ports are listening: $exposed" "close them in the AWS Security Group; the database and Redis must never be public"
echo "        Reminder: in AWS > EC2 > Security Groups, port 22 should allow only YOUR IP, and 80/443 may allow everyone."

echo; echo "5. Website protection headers (https://$APP_HOST)"
hdr=$(curl -sI "https://$APP_HOST/" 2>/dev/null | tr -d '\r')
for h in "Content-Security-Policy" "Strict-Transport-Security" "X-Content-Type-Options" "X-Frame-Options" "Referrer-Policy" "Permissions-Policy"; do
  echo "$hdr" | grep -qi "^$h:" && ok "$h present" || crit "$h missing" "deploy the latest version (deploy.sh)"
done
code=$(curl -s -o /dev/null -w "%{http_code}" "http://$APP_HOST/" 2>/dev/null); case "$code" in 301|302|307|308) ok "plain http redirects to https";; *) bad "http answered $code" "it should redirect to https";; esac

echo; echo "6. Safety net"
latest=$(find "$HOME/naadamaya-backups" -name 'naadamaya-*.sql.gz' -mtime -2 2>/dev/null | head -1)
[ -n "$latest" ] && ok "a database backup from the last 2 days exists" || bad "no recent backup" "run: bash $BACKEND_DIR/backup.sh"
use=$(df -P / | awk 'NR==2{gsub("%","");print $5}'); [ "${use:-0}" -lt 80 ] && ok "disk is ${use}% full" || bad "disk is ${use}% full" "free space or enlarge the disk"

echo; echo "Result: $pass passed, $warn warnings, $fail failed"
[ "$fail" -eq 0 ]

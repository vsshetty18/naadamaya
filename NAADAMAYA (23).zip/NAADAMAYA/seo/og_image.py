"""Makes public/og-image.png (1200x630), the picture shown when the site is shared. Run: python3 seo/og_image.py"""
from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 630
img = Image.new("RGB", (W, H), "#FDFAF4")
d = ImageDraw.Draw(img)
for y in range(H):  # soft warm gradient
    t = y / H
    d.line([(0, y), (W, y)], fill=(int(253 - 14 * t), int(250 - 30 * t), int(244 - 52 * t)))
logo = Image.open("src/assets/logo-mark.png").convert("RGB").resize((300, 300))
mask = Image.new("L", (300, 300), 0)
ImageDraw.Draw(mask).ellipse((0, 0, 299, 299), fill=255)
ring = Image.new("RGB", (320, 320), "#D9B37A")
rm = Image.new("L", (320, 320), 0)
ImageDraw.Draw(rm).ellipse((0, 0, 319, 319), fill=255)
img.paste(ring, (90, 155), rm)
img.paste(logo, (100, 165), mask)

serif_b = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
serif = "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"
d.text((470, 190), "NAADAMAYA", font=ImageFont.truetype(serif_b, 84), fill="#301C12")
d.text((474, 300), "sing. evolve. globally.", font=ImageFont.truetype(serif, 38), fill="#93582F")
d.text((474, 380), "Compare your singing with the", font=ImageFont.truetype(serif, 34), fill="#5E3720")
d.text((474, 424), "original song. Clear feedback on", font=ImageFont.truetype(serif, 34), fill="#5E3720")
d.text((474, 468), "pitch, timing and steadiness.", font=ImageFont.truetype(serif, 34), fill="#5E3720")
d.text((474, 548), "app.naadamaya.site", font=ImageFont.truetype(serif, 28), fill="#8a6a50")
img.save("public/og-image.png", optimize=True)
print("ok")

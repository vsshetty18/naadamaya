# SEO and AI-search files

`python3 seo/generate.py` rebuilds the public pages, sitemap.xml, robots.txt, llms.txt and llms-full.txt.
`python3 seo/og_image.py` rebuilds the share picture (public/og-image.png).
Edit the wording in `seo/generate.py`, never in the generated files. Keep it true: no invented reviews, ratings or user counts.
After deploying, submit https://app.naadamaya.site/sitemap.xml in Google Search Console and Bing Webmaster Tools.

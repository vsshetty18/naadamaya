import { useState } from 'react'
import { Share2 } from 'lucide-react'

import { useI18n } from '@/i18n'

/**
 * Draws a private score card as a PNG on the phone and hands it to the share sheet.
 * Nothing is uploaded and no public link is created: reports stay private.
 */
const FONT = "'Noto Sans Devanagari','Noto Sans Kannada',Georgia,'Times New Roman',serif"

function fit(ctx, text, maxWidth) {
  let s = String(text || '')
  while (s.length > 1 && ctx.measureText(s).width > maxWidth) s = s.slice(0, -2) + '…'
  return s
}

export async function drawCard({ score, song, level, label, tagline }) {
  try {
    await document.fonts?.ready
  } catch {
    /* fonts are optional */
  }
  const W = 1080
  const H = 1350
  const c = document.createElement('canvas')
  c.width = W
  c.height = H
  const ctx = c.getContext('2d')
  const g = ctx.createLinearGradient(0, 0, 0, H)
  g.addColorStop(0, '#FDFAF4')
  g.addColorStop(1, '#F3E3C8')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, W, H)
  ctx.textAlign = 'center'

  ctx.fillStyle = '#301C12'
  ctx.font = `600 56px ${FONT}`
  ctx.fillText('N A A D A M A Y A', W / 2, 150)
  ctx.fillStyle = '#93582F'
  ctx.font = `400 34px ${FONT}`
  ctx.fillText(tagline, W / 2, 205)

  ctx.strokeStyle = '#D9B37A'
  ctx.lineWidth = 10
  ctx.beginPath()
  ctx.arc(W / 2, 620, 250, 0, Math.PI * 2)
  ctx.stroke()
  if (score != null) {
    ctx.beginPath()
    ctx.strokeStyle = '#93582F'
    ctx.lineWidth = 18
    ctx.arc(W / 2, 620, 250, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * Math.min(100, score)) / 100)
    ctx.stroke()
  }
  ctx.fillStyle = '#301C12'
  ctx.font = `700 230px ${FONT}`
  ctx.fillText(score == null ? '—' : String(Math.round(score)), W / 2, 700)
  ctx.fillStyle = '#5E3720'
  ctx.font = `400 40px ${FONT}`
  ctx.fillText(label, W / 2, 790)

  ctx.fillStyle = '#301C12'
  ctx.font = `600 54px ${FONT}`
  ctx.fillText(fit(ctx, song, W - 160), W / 2, 1000)
  if (level) {
    ctx.fillStyle = '#93582F'
    ctx.font = `500 40px ${FONT}`
    ctx.fillText(level, W / 2, 1070)
  }
  ctx.fillStyle = '#8a6a50'
  ctx.font = `400 32px ${FONT}`
  ctx.fillText('app.naadamaya.site', W / 2, 1270)
  return new Promise((res) => c.toBlob(res, 'image/png'))
}

export default function ShareReport({ analysis }) {
  const { t } = useI18n()
  const [busy, setBusy] = useState(false)
  const [note, setNote] = useState('')

  async function share() {
    setBusy(true)
    setNote('')
    try {
      const blob = await drawCard({
        score: analysis.overallScore,
        song: analysis.original?.title || '',
        level: analysis.levelLabel || '',
        label: t('share.score', 'Overall score'),
        tagline: 'sing. evolve. globally.',
      })
      if (!blob) return
      const file = new File([blob], 'naadamaya-score.png', { type: 'image/png' })
      if (navigator.canShare?.({ files: [file] })) {
        try {
          await navigator.share({ files: [file], title: 'NAADAMAYA' })
        } catch (e) {
          if (e?.name !== 'AbortError') throw e
        }
      } else {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = 'naadamaya-score.png'
        document.body.appendChild(a)
        a.click()
        a.remove()
        setTimeout(() => URL.revokeObjectURL(url), 4000)
        setNote(t('share.saved', 'Image saved'))
      }
    } catch {
      setNote('')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        onClick={share}
        disabled={busy}
        className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-gold-200 bg-white px-5 text-[0.9rem] font-medium text-brown-700 disabled:opacity-60"
      >
        <Share2 className="h-4 w-4" aria-hidden="true" />
        {busy ? t('share.making', 'Preparing…') : t('share.button', 'Share report')}
      </button>
      {note && <span className="text-[0.85rem] text-brown-500" role="status">{note}</span>}
    </div>
  )
}

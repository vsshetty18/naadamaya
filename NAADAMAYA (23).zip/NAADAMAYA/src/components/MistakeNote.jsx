import { useI18n } from '@/i18n'
import { cn } from '@/utils/cn'

/** A small, honest reminder shown under results and on the home screens. */
export default function MistakeNote({ className }) {
  const { t } = useI18n()
  return (
    <p className={cn('text-center text-[0.75rem] leading-snug text-brown-400', className)}>
      {t('mistake.note', 'NAADAMAYA could make mistakes. Use its feedback as practice guidance and trust your teacher and your ear.')}
    </p>
  )
}

import { useI18n } from '@/i18n'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Mic, MicOff } from 'lucide-react'

import { getAudioContext } from '@/audio/engine'
import { detectPitch } from '@/utils/pitch'
import { freqToMidi, noteName, swaraOf } from '@/utils/music'
import { cn } from '@/utils/cn'

const median = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)]

export default function TunerPanel({ tonic }) {
  const { t } = useI18n()
  const [state, setState] = useState('idle') // idle | asking | on | denied | unsupported
  const [reading, setReading] = useState(null)
  const rt = useRef({ stream: null, timer: null, src: null, hist: [], lastGood: 0 })

  const stop = useCallback(() => {
    const r = rt.current
    clearInterval(r.timer)
    r.src?.disconnect()
    r.stream?.getTracks().forEach((t) => t.stop())
    rt.current = { stream: null, timer: null, src: null, hist: [], lastGood: 0 }
    setReading(null)
    setState((s) => (s === 'on' || s === 'asking' ? 'idle' : s))
  }, [])

  useEffect(() => stop, [stop])

  const start = async () => {
    if (!navigator.mediaDevices?.getUserMedia) return setState('unsupported')
    setState('asking')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false },
      })
      const ctx = getAudioContext()
      const src = ctx.createMediaStreamSource(stream)
      const an = ctx.createAnalyser()
      an.fftSize = 2048
      src.connect(an)
      const buf = new Float32Array(an.fftSize)
      const r = rt.current
      r.stream = stream
      r.src = src
      r.timer = setInterval(() => {
        an.getFloatTimeDomainData(buf)
        const hz = detectPitch(buf, ctx.sampleRate)
        const now = performance.now()
        if (hz) {
          r.lastGood = now
          r.hist = [...r.hist.slice(-4), freqToMidi(hz)]
          const midi = median(r.hist)
          setReading({ hz: (440 * 2 ** ((midi - 69) / 12)), midi })
        } else if (now - r.lastGood > 350) {
          r.hist = []
          setReading(null)
        }
      }, 60)
      setState('on')
    } catch {
      setState('denied')
    }
  }

  const n = reading ? Math.round(reading.midi) : null
  const cents = reading ? Math.round((reading.midi - n) * 100) : 0
  const sw = reading ? swaraOf(reading.midi, tonic.saMidi) : null
  const inTune = reading && Math.abs(cents) <= 10
  const needle = Math.max(-50, Math.min(50, cents))

  return (
    <section className="rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
      <h2 className="font-serif text-[1.15rem] font-semibold text-brown-900">{t('tuner.title', 'Tuner')}</h2>
      <p className="mt-1 text-[0.88rem] text-brown-500">{t('tuner.sub', 'Sing or hum one steady note. It shows which note you are on and how far off, in cents (100 cents = one semitone).')}</p>

      <button
        type="button"
        onClick={state === 'on' ? stop : start}
        disabled={state === 'asking'}
        className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-brown-600 px-5 py-3.5 text-[1rem] font-medium text-white disabled:opacity-60"
      >
        {state === 'on' ? <MicOff className="h-5 w-5" aria-hidden="true" /> : <Mic className="h-5 w-5" aria-hidden="true" />}
        {state === 'on' ? t('tuner.stop', 'Stop listening') : state === 'asking' ? t('tuner.wait', 'Waiting for microphone…') : t('tuner.start', 'Start listening')}
      </button>

      {state === 'denied' && (
        <p className="mt-3 rounded-xl bg-blush-100 px-4 py-3 text-[0.88rem] text-brown-700">{t('tuner.denied', 'Microphone access was blocked. Allow the microphone for this site in your browser or app settings, then try again.')}</p>
      )}
      {state === 'unsupported' && <p className="mt-3 text-[0.88rem] text-brown-700">{t('tuner.unsupported', 'This browser cannot use the microphone here.')}</p>}

      <div className="mt-5 text-center" aria-live="polite">
        <div className={cn('font-serif text-[3.2rem] font-semibold leading-none', inTune ? 'text-sage-600' : 'text-brown-800')}>
          {reading ? noteName(n) : '–'}
        </div>
        <div className="mt-2 min-h-[1.5rem] text-[1.05rem] text-brown-600">
          {reading && tonic.notation !== 'western' && `${sw.name} (${t(`octave.${sw.octave}`, sw.octave)})`}
        </div>
        <div className="mt-1 min-h-[1.2rem] text-[0.85rem] text-brown-400">{reading ? `${reading.hz.toFixed(1)} Hz · ${cents > 0 ? '+' : ''}${cents} cents` : state === 'on' ? t('tuner.listening', 'Listening…') : ''}</div>
      </div>

      <div className="relative mx-auto mt-4 h-3 w-full max-w-sm rounded-full bg-brown-100" role="img" aria-label={reading ? `${cents} cents` : 'no note'}>
        <div className="absolute left-1/2 top-[-4px] h-5 w-0.5 -translate-x-1/2 bg-sage-500" />
        {reading && (
          <div
            className={cn('absolute top-1/2 h-6 w-6 -translate-y-1/2 rounded-full border-2 border-white shadow transition-[left] duration-100', inTune ? 'bg-sage-500' : 'bg-gold-500')}
            style={{ left: `calc(${(needle + 50)}% - 12px)` }}
          />
        )}
      </div>
      <div className="mx-auto mt-1 flex max-w-sm justify-between text-[0.72rem] text-brown-400">
        <span>{t('tuner.flat', 'flat')}</span>
        <span>{t('tuner.inTune', 'in tune')}</span>
        <span>{t('tuner.sharp', 'sharp')}</span>
      </div>
    </section>
  )
}

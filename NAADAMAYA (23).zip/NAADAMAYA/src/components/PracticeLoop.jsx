import { useI18n } from '@/i18n'
import { useCallback, useEffect, useRef, useState } from 'react'
import { Pause, Play, Repeat } from 'lucide-react'

import { cn } from '@/utils/cn'
import { formatTime } from '@/utils/formatters'

const SPEEDS = [0.5, 0.75, 1]
const MIN_LOOP = 1 // seconds

/**
 * "Practise a section": plays the ORIGINAL song so you can sing along to just the part you need.
 *   - pick a section from the report, or set your own start and end
 *   - repeat it in a loop
 *   - slow it down to 75% or 50% (the pitch stays the same)
 * Nothing leaves the phone; it plays the file the report already loaded.
 */
export default function PracticeLoop({ analysis }) {
  const { t } = useI18n()
  const src = analysis?.original?.audioUrl || null
  const sections = (analysis?.sections || []).filter((s) => Number.isFinite(s.startTime) && Number.isFinite(s.endTime) && s.endTime - s.startTime >= MIN_LOOP)

  const audioRef = useRef(null)
  const loopRef = useRef(null)
  const [duration, setDuration] = useState(Number(analysis?.original?.duration) || 0)
  const [time, setTime] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [rate, setRate] = useState(1)
  const [loop, setLoop] = useState(null) // { start, end, label } or null
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    loopRef.current = loop
  }, [loop])

  useEffect(() => {
    if (!src) return undefined
    const a = new Audio(src)
    a.preload = 'metadata'
    a.preservesPitch = true
    a.webkitPreservesPitch = true
    a.mozPreservesPitch = true
    audioRef.current = a
    const onMeta = () => Number.isFinite(a.duration) && a.duration > 0 && setDuration(a.duration)
    const onEnd = () => setPlaying(false)
    const onErr = () => setFailed(true)
    a.addEventListener('loadedmetadata', onMeta)
    a.addEventListener('ended', onEnd)
    a.addEventListener('error', onErr)
    return () => {
      a.pause()
      a.removeEventListener('loadedmetadata', onMeta)
      a.removeEventListener('ended', onEnd)
      a.removeEventListener('error', onErr)
      audioRef.current = null
    }
  }, [src])

  // While playing: keep the display fresh and bring the playhead back at the end of the loop.
  useEffect(() => {
    if (!playing) return undefined
    const id = setInterval(() => {
      const a = audioRef.current
      if (!a) return
      const l = loopRef.current
      if (l && a.currentTime >= l.end - 0.03) a.currentTime = l.start
      setTime(a.currentTime)
    }, 50)
    return () => clearInterval(id)
  }, [playing])

  useEffect(() => {
    if (audioRef.current) audioRef.current.playbackRate = rate
  }, [rate, src])

  const play = useCallback(() => {
    const a = audioRef.current
    if (!a) return
    a.playbackRate = rate
    a.play().then(() => setPlaying(true)).catch(() => setFailed(true))
  }, [rate])
  const pause = useCallback(() => {
    audioRef.current?.pause()
    setPlaying(false)
  }, [])

  if (!src || failed) return null

  const seek = (t) => {
    const a = audioRef.current
    if (!a) return
    a.currentTime = Math.max(0, Math.min(t, duration || t))
    setTime(a.currentTime)
  }
  const chooseSection = (s) => {
    const l = { start: s.startTime, end: s.endTime, label: s.sectionName || 'Section' }
    setLoop(l)
    loopRef.current = l
    seek(l.start)
    play()
  }
  const setPoint = (which) => {
    const now = audioRef.current?.currentTime ?? time
    setLoop((prev) => {
      const next = prev ? { ...prev } : { start: 0, end: duration || now + MIN_LOOP, label: 'Your loop' }
      if (which === 'start') next.start = now
      else next.end = now
      next.label = 'Your loop'
      if (next.end - next.start < MIN_LOOP) return prev // too short to loop
      loopRef.current = next
      return next
    })
  }
  const clearLoop = () => {
    setLoop(null)
    loopRef.current = null
  }

  const from = loop ? loop.start : 0
  const to = loop ? loop.end : duration || 1
  const pct = to > from ? Math.max(0, Math.min(100, ((time - from) / (to - from)) * 100)) : 0

  const pill = (on) => cn('rounded-full border px-3 py-1.5 text-[0.82rem] font-medium', on ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 bg-white/70 text-brown-700')

  return (
    <section aria-label="Practise a section" className="nm-card animate-fade-up p-4 sm:p-5">
      <h2 className="font-serif text-[1.1rem] font-semibold text-brown-900">{t('loop.title', 'Practise a section')}</h2>
      <p className="mt-0.5 text-[0.82rem] text-brown-500">{t('loop.sub', 'Sing along with just the part you need. Slowing it down keeps the pitch the same.')}</p>

      {sections.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5" role="group" aria-label="Sections">
          {sections.map((s) => (
            <button key={s.id ?? s.startTime} type="button" onClick={() => chooseSection(s)} className={pill(loop?.start === s.startTime && loop?.end === s.endTime)}>
              {s.sectionName || 'Section'} <span className="opacity-70">{formatTime(s.startTime)}</span>
            </button>
          ))}
        </div>
      )}

      <div className="mt-4 flex items-center gap-3">
        <button
          type="button"
          onClick={playing ? pause : play}
          aria-label={playing ? 'Pause' : 'Play'}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-brown-600 text-white"
        >
          {playing ? <Pause className="h-5 w-5" aria-hidden="true" /> : <Play className="h-5 w-5" aria-hidden="true" />}
        </button>
        <div className="min-w-0 flex-1">
          <div className="h-2 w-full overflow-hidden rounded-full bg-brown-100">
            <div className="h-full rounded-full bg-gold-400" style={{ width: `${pct}%` }} />
          </div>
          <div className="mt-1 flex justify-between text-[0.75rem] text-brown-500">
            <span>{formatTime(time)}</span>
            <span className="truncate">{loop ? `${loop.label}: ${formatTime(loop.start)} - ${formatTime(loop.end)}` : t('loop.whole', 'Whole song')}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <span className="text-[0.78rem] font-medium uppercase tracking-wide text-brown-400">{t('common.speed', 'Speed')}</span>
        {SPEEDS.map((r) => (
          <button key={r} type="button" onClick={() => setRate(r)} aria-pressed={rate === r} className={pill(rate === r)}>
            {r === 1 ? t('loop.normal', 'Normal') : `${Math.round(r * 100)}%`}
          </button>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Repeat className={cn('h-4 w-4', loop ? 'text-gold-500' : 'text-brown-300')} aria-hidden="true" />
        <button type="button" onClick={() => setPoint('start')} className={pill(false)}>{t('loop.startHere', 'Start here')}</button>
        <button type="button" onClick={() => setPoint('end')} className={pill(false)}>{t('loop.endHere', 'End here')}</button>
        {loop && (
          <button type="button" onClick={clearLoop} className="rounded-full px-3 py-1.5 text-[0.82rem] text-brown-500 underline underline-offset-2">
            {t('loop.clear', 'Clear loop')}
          </button>
        )}
      </div>
    </section>
  )
}

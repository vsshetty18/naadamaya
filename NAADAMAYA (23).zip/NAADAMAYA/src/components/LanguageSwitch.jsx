import { LANGUAGES, useI18n } from '@/i18n'
import { cn } from '@/utils/cn'

/** English / हिन्दी / ಕನ್ನಡ. The choice is remembered on this device. */
export default function LanguageSwitch({ className }) {
  const { lang, setLang, t } = useI18n()
  return (
    <div className={cn('flex flex-wrap items-center gap-2', className)} role="radiogroup" aria-label={t('lang.title', 'Language')}>
      <span className="text-[0.8rem] text-brown-500">{t('lang.title', 'Language')}</span>
      {LANGUAGES.map((l) => (
        <button
          key={l.code}
          type="button"
          role="radio"
          aria-checked={lang === l.code}
          onClick={() => setLang(l.code)}
          className={cn('rounded-full border px-3.5 py-1.5 text-[0.85rem] font-medium', lang === l.code ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 bg-white/70 text-brown-700')}
        >
          {l.label}
        </button>
      ))}
    </div>
  )
}

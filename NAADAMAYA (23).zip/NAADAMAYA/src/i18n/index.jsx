import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'

import hi from '@/i18n/hi'
import kn from '@/i18n/kn'

/**
 * Screen language (English, Hindi, Kannada). Components write
 *     t('practice.title', 'Your practice')
 * The second argument is the English text, shown whenever a translation is missing,
 * so a gap in a dictionary can never break a screen. {name} placeholders are filled from the third argument.
 * Words written by the analysis server (report insights and tips) are still English.
 */
export const LANGUAGES = [
  { code: 'en', label: 'English', dict: null },
  { code: 'hi', label: 'हिन्दी', dict: hi },
  { code: 'kn', label: 'ಕನ್ನಡ', dict: kn },
]
const KEY = 'nm_lang'

function loadFont(code) {
  // Self-hosted fonts (no Google request). Loaded only for the language that needs them.
  if (code === 'hi') {
    import('@fontsource/noto-sans-devanagari/400.css')
    import('@fontsource/noto-sans-devanagari/500.css')
    import('@fontsource/noto-sans-devanagari/600.css')
  } else if (code === 'kn') {
    import('@fontsource/noto-sans-kannada/400.css')
    import('@fontsource/noto-sans-kannada/500.css')
    import('@fontsource/noto-sans-kannada/600.css')
  }
}

function initial() {
  try {
    const v = localStorage.getItem(KEY)
    if (LANGUAGES.some((l) => l.code === v)) return v
  } catch {
    /* storage unavailable */
  }
  return 'en'
}

const I18nContext = createContext({ lang: 'en', setLang: () => {}, t: (_k, fallback) => fallback })

export function I18nProvider({ children }) {
  const [lang, setLangState] = useState(initial)

  useEffect(() => {
    document.documentElement.lang = lang
    loadFont(lang)
  }, [lang])

  const setLang = useCallback((code) => {
    if (!LANGUAGES.some((l) => l.code === code)) return
    try {
      localStorage.setItem(KEY, code)
    } catch {
      /* ignore */
    }
    setLangState(code)
  }, [])

  const value = useMemo(() => {
    const dict = LANGUAGES.find((l) => l.code === lang)?.dict || null
    const t = (key, fallback, vars) => {
      let text = (dict && dict[key]) || fallback || key
      if (vars) for (const [k, v] of Object.entries(vars)) text = text.split(`{${k}}`).join(String(v))
      return text
    }
    return { lang, setLang, t }
  }, [lang, setLang])

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export const useI18n = () => useContext(I18nContext)

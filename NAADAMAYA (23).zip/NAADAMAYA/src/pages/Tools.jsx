import { useI18n } from '@/i18n'
import { useState } from 'react'

import TanpuraPanel from '@/components/tools/TanpuraPanel'
import TunerPanel from '@/components/tools/TunerPanel'
import TalaPanel from '@/components/tools/TalaPanel'
import { useTonic } from '@/hooks/useTonic'
import { NOTE_NAMES } from '@/utils/music'
import { cn } from '@/utils/cn'

/**
 * Practice tools that need no reference song: tanpura, tuner, tala keeper.
 * Everything runs on the phone. No audio or microphone data is sent anywhere.
 */
const TABS = [
  { id: 'tanpura', label: 'Tanpura' },
  { id: 'tuner', label: 'Tuner' },
  { id: 'tala', label: 'Tala' },
]

export default function Tools() {
  const { t } = useI18n()
  const tonic = useTonic()
  const [current, setCurrent] = useState('tanpura')

  return (
    <div className="pt-2">
      <h1 className="font-serif text-[1.6rem] font-semibold text-brown-900">{t('tools.title', 'Practice tools')}</h1>
      <p className="mt-1 text-[0.9rem] text-brown-500">{t('tools.sub', 'Set your Sa once. The tanpura, tuner and ear training all follow it.')}</p>

      <section className="mt-5 rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
        <h2 className="text-[0.8rem] font-medium uppercase tracking-wide text-brown-400">{t('tools.sa', 'Your Sa')}</h2>
        <div className="mt-2 grid grid-cols-6 gap-1.5" role="radiogroup" aria-label="Your Sa">
          {NOTE_NAMES.map((n, i) => (
            <button
              key={n}
              type="button"
              role="radio"
              aria-checked={tonic.pitchClass === i}
              onClick={() => tonic.update({ pitchClass: i })}
              className={cn(
                'rounded-lg border py-2 text-[0.85rem] font-medium',
                tonic.pitchClass === i ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 bg-white/70 text-brown-700'
              )}
            >
              {n}
            </button>
          ))}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {[
            [false, t('tools.low', 'Lower voice')],
            [true, t('tools.high', 'Higher voice')],
          ].map(([v, label]) => (
            <button
              key={label}
              type="button"
              onClick={() => tonic.update({ high: v })}
              className={cn('rounded-full border px-3.5 py-1.5 text-[0.85rem] font-medium', tonic.high === v ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 text-brown-700')}
            >
              {label}
            </button>
          ))}
          <span className="mx-1 text-brown-300">|</span>
          {[
            ['both', 'Sa Re · C D'],
            ['swara', 'Sa Re Ga'],
            ['western', 'C D E'],
          ].map(([v, label]) => (
            <button
              key={v}
              type="button"
              onClick={() => tonic.update({ notation: v })}
              className={cn('rounded-full border px-3.5 py-1.5 text-[0.85rem] font-medium', tonic.notation === v ? 'border-brown-600 bg-brown-600 text-white' : 'border-brown-200 text-brown-700')}
            >
              {label}
            </button>
          ))}
        </div>
      </section>

      <div className="mt-5 grid grid-cols-3 gap-1.5 rounded-full bg-brown-50 p-1" role="tablist">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={current === tab.id}
            onClick={() => setCurrent(tab.id)}
            className={cn('rounded-full py-2.5 text-[0.92rem] font-medium', current === tab.id ? 'bg-white text-brown-800 shadow-sm' : 'text-brown-500')}
          >
            {t(`tab.${tab.id}`, tab.label)}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {current === 'tanpura' && <TanpuraPanel tonic={tonic} />}
        {current === 'tuner' && <TunerPanel tonic={tonic} />}
        {current === 'tala' && <TalaPanel />}
      </div>
    </div>
  )
}

import { useEffect } from 'react'
import { Link } from 'react-router-dom'

import Tools from '@/pages/Tools'
import { useI18n } from '@/i18n'

/** Tools without sign-in. Works offline once the app has been opened once online. */
export default function PracticeOffline() {
  const { t } = useI18n()
  useEffect(() => {
    const before = document.title
    document.title = 'Free tanpura, tuner and tala tools | NAADAMAYA'
    return () => {
      document.title = before
    }
  }, [])
  return (
    <div className="mx-auto min-h-screen max-w-2xl bg-[#FDFAF4] px-4 pb-10 pt-4">
      <Link to="/" className="text-[0.9rem] text-brown-500 underline">
        {t('practice.back', 'Back to NAADAMAYA')}
      </Link>
      <Tools />
    </div>
  )
}

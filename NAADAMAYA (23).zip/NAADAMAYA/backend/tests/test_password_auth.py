"""Phone + password sign-in: register, login, lockout, change password, OTP switched off."""

from app.core.config import settings
from app.core.passwords import hash_password, verify_password
from app.models.user import User
from sqlalchemy import select

from tests.conftest import phone_number

GOOD = "Sur-Sadhana-2026"


def reg(client, phone, password=GOOD):
    return client.post("/api/v1/auth/register", json={"phone_number": phone, "password": password})


def log_in(client, phone, password=GOOD):
    return client.post("/api/v1/auth/login", json={"phone_number": phone, "password": password})


def test_hash_roundtrip_and_salt():
    a, b = hash_password("abcdefgh1"), hash_password("abcdefgh1")
    assert a != b and verify_password("abcdefgh1", a) and not verify_password("abcdefgh2", a)
    assert not verify_password("x", None) and not verify_password("x", "garbage")


def test_register_then_login_and_me(client, db):
    r = reg(client, phone_number(1))
    assert r.status_code == 200 and r.json()["is_new_user"] is True
    user = db.scalar(select(User))
    assert user.password_hash.startswith("scrypt$") and GOOD not in user.password_hash
    r2 = log_in(client, phone_number(1))
    assert r2.status_code == 200 and r2.json()["is_new_user"] is False
    me = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {r2.json()['access_token']}"})
    assert me.status_code == 200


def test_duplicate_register_refused(client):
    assert reg(client, phone_number(1)).status_code == 200
    r = reg(client, phone_number(1), "Another-Pass-77")
    assert r.status_code == 409 and r.json()["error"]["code"] == "PHONE_TAKEN"


def test_weak_passwords_refused(client):
    for pw in ("short1", "password123", "aaaaaaaaaa"):
        r = reg(client, phone_number(2), pw)
        assert r.status_code == 422 and r.json()["error"]["code"] == "WEAK_PASSWORD", pw


def test_wrong_password_and_unknown_number_look_the_same(client):
    reg(client, phone_number(1))
    a = log_in(client, phone_number(1), "Wrong-Password-1")
    b = log_in(client, phone_number(3), GOOD)
    assert a.status_code == b.status_code == 401
    assert a.json()["error"] == b.json()["error"]


def test_lockout_after_repeated_failures(client, monkeypatch):
    monkeypatch.setattr(settings, "login_max_failures", 3)
    reg(client, phone_number(1))
    for _ in range(3):
        assert log_in(client, phone_number(1), "Wrong-Password-1").status_code == 401
    locked = log_in(client, phone_number(1), GOOD)  # even the right password waits
    assert locked.status_code == 429 and locked.json()["error"]["code"] == "ACCOUNT_LOCKED"


def test_success_resets_failure_count(client, monkeypatch, db):
    monkeypatch.setattr(settings, "login_max_failures", 3)
    reg(client, phone_number(1))
    log_in(client, phone_number(1), "Wrong-Password-1")
    assert log_in(client, phone_number(1)).status_code == 200
    assert db.scalar(select(User)).failed_login_count == 0


def test_change_password_signs_out_everywhere(client):
    tokens = reg(client, phone_number(1)).json()
    h = {"Authorization": f"Bearer {tokens['access_token']}"}
    bad = client.post("/api/v1/auth/change-password", headers=h, json={"current_password": "nope-nope-1", "new_password": "New-Sur-Pass-9"})
    assert bad.status_code == 401
    ok = client.post("/api/v1/auth/change-password", headers=h, json={"current_password": GOOD, "new_password": "New-Sur-Pass-9"})
    assert ok.status_code == 200
    assert client.post("/api/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]}).status_code == 401
    assert log_in(client, phone_number(1)).status_code == 401
    assert log_in(client, phone_number(1), "New-Sur-Pass-9").status_code == 200


def test_otp_routes_off_by_default(client, monkeypatch):
    monkeypatch.setattr(settings, "auth_otp_enabled", False)
    assert client.post("/api/v1/auth/send-otp", json={"phone_number": phone_number(1)}).status_code == 404


def test_account_without_password_cannot_log_in(client, login):
    login(1)  # made through the old OTP flow: no password
    assert log_in(client, phone_number(1)).status_code == 401


# ---------------- forgot password (SMS code) ----------------
def forgot(client, phone):
    return client.post("/api/v1/auth/forgot-password", json={"phone_number": phone})


def do_reset(client, phone, code="123456", pw="Fresh-Sur-Pass-5"):
    return client.post("/api/v1/auth/reset-password", json={"phone_number": phone, "code": code, "new_password": pw})


def test_forgot_and_reset_flow(client, db):
    from app.models.otp import OtpCode

    tokens = reg(client, phone_number(1)).json()
    assert forgot(client, phone_number(1)).status_code == 200
    assert db.scalar(select(OtpCode).where(OtpCode.purpose == "PASSWORD_RESET")) is not None
    bad = do_reset(client, phone_number(1), code="000000")
    assert bad.status_code == 400 and bad.json()["error"]["code"] == "INVALID_OTP"
    assert do_reset(client, phone_number(1)).status_code == 200
    assert log_in(client, phone_number(1), GOOD).status_code == 401
    assert log_in(client, phone_number(1), "Fresh-Sur-Pass-5").status_code == 200
    assert client.post("/api/v1/auth/refresh", json={"refresh_token": tokens["refresh_token"]}).status_code == 401
    assert do_reset(client, phone_number(1), pw="Third-Sur-Pass-8").status_code != 200  # one use only


def test_forgot_is_silent_and_sends_nothing_for_unknown_number(client, db):
    from app.models.otp import OtpCode

    reg(client, phone_number(6))
    a, b = forgot(client, phone_number(5)), forgot(client, phone_number(6))
    assert a.status_code == b.status_code == 200 and a.json() == b.json()
    rows = db.scalars(select(OtpCode)).all()
    assert [r.phone_number_normalized for r in rows] == [phone_number(6).replace(" ", "")] or len(rows) == 1


def test_reset_rejects_weak_password_without_using_code(client):
    reg(client, phone_number(1))
    forgot(client, phone_number(1))
    assert do_reset(client, phone_number(1), pw="short").status_code == 422
    assert do_reset(client, phone_number(1)).status_code == 200


def test_reset_code_locks_after_wrong_tries(client):
    reg(client, phone_number(1))
    forgot(client, phone_number(1))
    for _ in range(settings.otp_max_verify_attempts):
        do_reset(client, phone_number(1), code="000000")
    assert do_reset(client, phone_number(1)).status_code != 200


# ---------------- email sign-in ----------------
def test_register_with_email_then_login_by_email(client):
    r = client.post("/api/v1/auth/register", json={"phone_number": phone_number(1), "password": GOOD, "email": "Singer@Example.com"})
    assert r.status_code == 200
    for who in ("singer@example.com", "SINGER@example.com", " singer@example.com "):
        ok = client.post("/api/v1/auth/login", json={"identifier": who, "password": GOOD})
        assert ok.status_code == 200, who
    assert client.post("/api/v1/auth/login", json={"identifier": "singer@example.com", "password": "Wrong-Pass-123"}).status_code == 401
    assert client.post("/api/v1/auth/login", json={"identifier": "nobody@example.com", "password": GOOD}).status_code == 401
    # the phone number still works, including the old field name
    assert client.post("/api/v1/auth/login", json={"phone_number": phone_number(1), "password": GOOD}).status_code == 200


def test_email_must_be_unique(client):
    client.post("/api/v1/auth/register", json={"phone_number": phone_number(1), "password": GOOD, "email": "a@example.com"})
    dup = client.post("/api/v1/auth/register", json={"phone_number": phone_number(2), "password": GOOD, "email": "A@Example.com"})
    assert dup.status_code == 409 and dup.json()["error"]["code"] == "EMAIL_TAKEN"
    tokens = reg(client, phone_number(3)).json()
    h = {"Authorization": f"Bearer {tokens['access_token']}"}
    r = client.put("/api/v1/profile", headers=h, json={"email": "a@example.com"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "EMAIL_TAKEN"
    assert client.put("/api/v1/profile", headers=h, json={"email": "c@example.com"}).status_code == 200
    assert client.post("/api/v1/auth/login", json={"identifier": "c@example.com", "password": GOOD}).status_code == 200


def test_email_login_locks_like_phone_login(client, monkeypatch):
    monkeypatch.setattr(settings, "login_max_failures", 3)
    client.post("/api/v1/auth/register", json={"phone_number": phone_number(1), "password": GOOD, "email": "a@example.com"})
    for _ in range(3):
        client.post("/api/v1/auth/login", json={"identifier": "a@example.com", "password": "Wrong-Pass-123"})
    assert client.post("/api/v1/auth/login", json={"identifier": phone_number(1), "password": GOOD}).status_code == 429

"""case-insensitive unique email (email can now be used to sign in)

Revision ID: 0004
Revises: 0003
Create Date: 2026-11-20
"""
from typing import Sequence, Union

from alembic import op

revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Unique if no two accounts already share an email. Otherwise a plain index, and the app
    # refuses to sign in to an email that is shared (and blocks new duplicates).
    op.execute(
        """
        DO $$
        BEGIN
          IF EXISTS (SELECT 1 FROM profiles WHERE email IS NOT NULL GROUP BY lower(email) HAVING count(*) > 1) THEN
            CREATE INDEX IF NOT EXISTS ix_profiles_email_lower ON profiles (lower(email)) WHERE email IS NOT NULL;
          ELSE
            CREATE UNIQUE INDEX IF NOT EXISTS ix_profiles_email_lower ON profiles (lower(email)) WHERE email IS NOT NULL;
          END IF;
        END $$;
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_profiles_email_lower")

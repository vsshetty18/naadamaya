"""Email as a second way to sign in. The email is typed by the user and not verified by a code."""

import uuid

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.profile import Profile
from app.models.user import User


def email_in_use(db: Session, email: str, *, exclude_user_id: uuid.UUID | None = None) -> bool:
    stmt = select(func.count()).select_from(Profile).where(func.lower(Profile.email) == email.lower())
    if exclude_user_id is not None:
        stmt = stmt.where(Profile.user_id != exclude_user_id)
    return (db.scalar(stmt) or 0) > 0


def users_by_email(db: Session, email: str) -> list[User]:
    return list(
        db.scalars(
            select(User).join(Profile, Profile.user_id == User.id).where(func.lower(Profile.email) == email.strip().lower())
        )
    )

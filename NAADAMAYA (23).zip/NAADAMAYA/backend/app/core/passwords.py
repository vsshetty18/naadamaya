"""
Password hashing with scrypt (Python standard library, no extra package).

Stored as:  scrypt$N$r$p$salt_b64$hash_b64
Every password gets its own random 16-byte salt. Comparison is constant-time.
The parameters are stored with the hash, so they can be raised later and old
hashes still verify.
"""

import base64
import hashlib
import hmac
import os

_N, _R, _P = 2**14, 8, 1  # about 16 MB and ~50 ms per hash
_KEYLEN = 32

MIN_LENGTH = 8
MAX_LENGTH = 128

_COMMON = {
    "password", "password1", "password123", "passw0rd", "12345678", "123456789", "1234567890",
    "qwerty123", "qwertyuiop", "11111111", "00000000", "iloveyou", "welcome1", "admin123",
    "letmein1", "abc12345", "abcd1234", "naadamaya", "naadamaya1", "naadamaya123", "sa re ga ma",
    "saregama", "saregama1", "india123", "krishna123", "shiva123", "ganesh123",
}


def _b64(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=_N, r=_R, p=_P, dklen=_KEYLEN, maxmem=64 * 1024 * 1024)
    return f"scrypt${_N}${_R}${_P}${_b64(salt)}${_b64(digest)}"


def verify_password(password: str, stored: str | None) -> bool:
    """False for a wrong password or a malformed hash. Never raises."""
    try:
        scheme, n, r, p, salt, digest = (stored or "").split("$")
        if scheme != "scrypt":
            return False
        expected = base64.b64decode(digest)
        got = hashlib.scrypt(
            password.encode("utf-8"), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p),
            dklen=len(expected), maxmem=64 * 1024 * 1024,
        )
        return hmac.compare_digest(got, expected)
    except Exception:
        return False


# A real hash of a throwaway value. Used so that "no such account" takes as long as a wrong password.
_DUMMY = hash_password("naadamaya-dummy-password")


def burn_time() -> None:
    verify_password("x", _DUMMY)


def password_problem(password: str, phone_digits: str = "") -> str | None:
    """A plain-words reason the password is not acceptable, or None when it is fine."""
    if len(password) < MIN_LENGTH:
        return f"Use at least {MIN_LENGTH} characters."
    if len(password) > MAX_LENGTH:
        return f"Use at most {MAX_LENGTH} characters."
    low = password.lower()
    if low in _COMMON or len(set(low)) < 4:
        return "That password is too easy to guess. Try a longer one that is not a common word."
    digits = "".join(ch for ch in password if ch.isdigit())
    if phone_digits and (digits and (digits in phone_digits or phone_digits[-10:] in password)) and len(digits) >= 6 and digits == password:
        return "Do not use your phone number as your password."
    return None

"""
Support/owner tool: list everyone who has an account, with their details.

    docker compose -f docker-compose.prod.yml exec api python -m app.scripts.list_users          # table on screen
    docker compose -f docker-compose.prod.yml exec api python -m app.scripts.list_users --csv > users.csv

Shows full phone numbers, so keep the file private. Passwords are hashed and cannot be shown.
"""

import csv
import sys

from sqlalchemy import text

from app.core.database import SessionLocal

SQL = text(
    """
    SELECT u.created_at AS joined, u.phone_number AS phone, p.display_name AS name, p.email AS email,
           p.experience_level AS level, p.preferred_language AS app_language,
           p.vocal_range_low AS low, p.vocal_range_high AS high,
           COALESCE(pl.name, '-') AS plan,
           (SELECT COUNT(*) FROM analyses a WHERE a.user_id = u.id) AS attempts,
           u.last_login_at AS last_login,
           CASE WHEN u.password_hash IS NULL THEN 'no' ELSE 'yes' END AS has_password,
           u.status AS status
    FROM users u
    LEFT JOIN profiles p ON p.user_id = u.id
    LEFT JOIN subscriptions s ON s.user_id = u.id AND s.status = 'ACTIVE'
    LEFT JOIN plans pl ON pl.id = s.plan_id
    WHERE u.is_deleted = false
    ORDER BY u.created_at DESC
    """
)


def main() -> int:
    with SessionLocal() as db:
        result = db.execute(SQL)
        cols = list(result.keys())
        rows = [["" if v is None else str(v)[:19] if hasattr(v, "isoformat") else str(v) for v in r] for r in result]
    if "--csv" in sys.argv:
        w = csv.writer(sys.stdout)
        w.writerow(cols)
        w.writerows(rows)
        return 0
    widths = [max(len(c), *(len(r[i]) for r in rows)) if rows else len(c) for i, c in enumerate(cols)]
    print("  ".join(c.ljust(widths[i]) for i, c in enumerate(cols)))
    for r in rows:
        print("  ".join(v.ljust(widths[i]) for i, v in enumerate(r)))
    print(f"\n{len(rows)} account(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

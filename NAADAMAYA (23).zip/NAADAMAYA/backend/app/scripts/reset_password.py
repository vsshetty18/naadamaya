"""
Support tool: set a new password for an account (forgotten password, or an
account made before password sign-in).

    docker compose -f docker-compose.prod.yml exec api python -m app.scripts.reset_password +919876543210

It asks for the new password (typed hidden). It signs the account out everywhere.
"""

import getpass
import sys

from app.core.database import SessionLocal
from app.core.exceptions import AppError
from app.services.auth.auth_service import set_password_for_phone


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python -m app.scripts.reset_password <phone number>")
        return 2
    phone = sys.argv[1]
    password = getpass.getpass("New password: ")
    if password != getpass.getpass("Type it again: "):
        print("The two passwords do not match.")
        return 1
    with SessionLocal() as db:
        try:
            ok = set_password_for_phone(db, phone, password)
            db.commit()
        except AppError as exc:
            print(exc.message)
            return 1
    print("Password updated." if ok else "No account with that phone number.")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

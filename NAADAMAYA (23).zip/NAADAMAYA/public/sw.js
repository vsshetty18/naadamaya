/*
 * NAADAMAYA service worker. It is deliberately small and safe:
 *  - It never touches /api or /health (login, payments, audio always go to the server).
 *  - Pages: network first. Offline: /practice and /tools open the saved app so the tanpura,
 *    tuner and tala still work; every other page shows /offline.html.
 *  - /assets and /icons (names change when the code changes): cache first.
 * Change VERSION to force every phone to drop its old cache.
 */
const VERSION = 'naadamaya-v3'
const ASSET_CACHE = `${VERSION}-assets`
const SHELL_CACHE = `${VERSION}-shell`
const OFFLINE_PAGES = ['/practice', '/tools']

async function precacheShell() {
  const shell = await caches.open(SHELL_CACHE)
  await shell.add('/offline.html')
  try {
    const res = await fetch('/', { cache: 'no-store' })
    if (!res.ok) return
    const html = await res.text()
    await shell.put('/__shell', new Response(html, { headers: { 'content-type': 'text/html' } }))
    const assets = await caches.open(ASSET_CACHE)
    const urls = [...new Set([...html.matchAll(/["'(](\/assets\/[^"'()\s]+)/g)].map((m) => m[1]))]
    await Promise.all(urls.map((u) => assets.add(u).catch(() => {})))
  } catch {
    /* offline shell is a bonus; install must not fail */
  }
}

self.addEventListener('install', (event) => {
  event.waitUntil(precacheShell().then(() => self.skipWaiting()))
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  const req = event.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return
  if (url.pathname.startsWith('/api') || url.pathname.startsWith('/health')) return
  if (req.headers.has('range')) return

  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).catch(async () => {
        if (OFFLINE_PAGES.includes(url.pathname)) {
          const shell = await caches.match('/__shell')
          if (shell) return shell
        }
        return caches.match('/offline.html')
      })
    )
    return
  }

  if (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/icons/')) {
    event.respondWith(
      caches.open(ASSET_CACHE).then((cache) =>
        cache.match(req, { ignoreVary: true }).then(
          (hit) =>
            hit ||
            fetch(req).then((res) => {
              if (res.ok) cache.put(req, res.clone())
              return res
            })
        )
      )
    )
  }
})

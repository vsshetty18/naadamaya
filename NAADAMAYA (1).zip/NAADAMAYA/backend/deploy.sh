#!/usr/bin/env bash
# NAADAMAYA one-command deploy.
# Usage (on the server):   bash ~/NAADAMAYA/backend/deploy.sh
# Safe to run again: it keeps your existing .env and database.
set -euo pipefail

BACKEND_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$BACKEND_DIR")"
cd "$BACKEND_DIR"

API_HOST="api.naadamaya.site"
APP_HOST="app.naadamaya.site"
COMPOSE=(docker compose -f docker-compose.prod.yml)

say() { printf '\n== %s\n' "$*"; }
die() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }

say "1/7  Checking Docker"
docker info >/dev/null 2>&1 || die "Docker is not available to this user. Close this terminal tab, open a new one and run the script again."

say "2/7  Cleaning leftovers from earlier attempts"
rm -f .dockerignoreprintf .envPGPASS* 2>/dev/null || true

say "3/7  Preparing the secrets file (.env)"
env_ok() {
  [ -f .env ] || return 1
  local p u j t
  p=$(grep -E '^POSTGRES_PASSWORD=' .env | tail -n1 | cut -d= -f2- || true)
  u=$(grep -E '^DATABASE_URL=' .env | tail -n1 || true)
  j=$(grep -E '^JWT_SECRET=' .env | tail -n1 | cut -d= -f2- || true)
  t=$(grep -E '^TOKEN_HASH_SECRET=' .env | tail -n1 | cut -d= -f2- || true)
  [ -n "$p" ] && [ -n "$j" ] && [ -n "$t" ] && [ "$j" != "$t" ] && [[ "$u" == *":$p@db:"* ]]
}
if env_ok; then
  sed -i '/^EOF$/d' .env
  echo "Keeping your existing .env"
else
  if docker volume ls -q 2>/dev/null | grep -q 'pgdata$'; then
    die "A database already exists but .env is missing or damaged. Stop here and tell me, so no data is lost."
  fi
  PGPASS=$(openssl rand -hex 24)
  JWT=$(openssl rand -hex 48)
  THS=$(openssl rand -hex 48)
  cat > .env <<ENVEOF
APP_NAME=NAADAMAYA
ENVIRONMENT=staging
DEBUG=false
API_V1_PREFIX=/api/v1
FRONTEND_URL=https://${APP_HOST}
CORS_ORIGINS=https://${APP_HOST}
TRUST_PROXY_HEADERS=true
POSTGRES_PASSWORD=${PGPASS}
DATABASE_URL=postgresql+psycopg://naadamaya:${PGPASS}@db:5432/naadamaya
REDIS_URL=redis://redis:6379/0
JWT_SECRET=${JWT}
TOKEN_HASH_SECRET=${THS}
JWT_ALGORITHM=HS256
JWT_ACCESS_EXPIRE_MINUTES=15
JWT_REFRESH_EXPIRE_DAYS=30
OTP_MODE=development
OTP_PROVIDER=mock
OTP_DEV_FIXED_CODE=123456
STORAGE_PROVIDER=local
STORAGE_LOCAL_DIR=/data/uploads
ANALYSIS_MODE=real
MAX_UPLOAD_SIZE_MB=50
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
RAZORPAY_WEBHOOK_SECRET=
ENVEOF
  echo "Created a new .env with fresh random secrets"
fi
chmod 600 .env
env_ok || die "The .env file is still not valid."

say "4/7  Checking the Docker and Caddy settings"
"${COMPOSE[@]}" config -q || die "docker-compose.prod.yml is not valid."

say "5/7  Building the website (first time: 2-4 minutes)"
docker run --rm -v "$ROOT_DIR":/app -w /app node:20-alpine \
  sh -c "npm install --no-audit --no-fund && npm run build" \
  || die "The website build failed. Send me the messages above."
[ -f "$ROOT_DIR/dist/index.html" ] || die "The website build produced no files."

say "6/7  Building and starting the backend (first time: 5-10 minutes)"
"${COMPOSE[@]}" up -d --build || die "Docker could not start the backend. Send me the messages above."

say "7/7  Waiting for everything to answer"
ok=0
for _ in $(seq 1 60); do
  if "${COMPOSE[@]}" exec -T api curl -fsS http://localhost:8000/health >/dev/null 2>&1; then ok=1; break; fi
  sleep 5
done
if [ "$ok" != 1 ]; then
  echo; "${COMPOSE[@]}" ps || true
  echo; "${COMPOSE[@]}" logs --tail 60 api || true
  die "The backend did not start. Send me the text above."
fi
echo "Backend is running."

pub=0
for _ in $(seq 1 36); do
  if curl -fsS "https://${API_HOST}/health" >/dev/null 2>&1; then pub=1; break; fi
  sleep 5
done
if [ "$pub" != 1 ]; then
  echo; "${COMPOSE[@]}" logs --tail 40 caddy || true
  die "The backend runs, but https://${API_HOST} does not answer yet. Check the DNS record for 'api' and wait 5 minutes, then run this script again."
fi
echo "https://${API_HOST}/health is answering."

app=0
for _ in $(seq 1 24); do
  if curl -fsS -o /dev/null "https://${APP_HOST}/"; then app=1; break; fi
  sleep 5
done
echo
"${COMPOSE[@]}" ps
echo
if [ "$app" = 1 ]; then
  echo "ALL DONE.  Open  https://${APP_HOST}  in your browser."
else
  echo "Backend is live, but https://${APP_HOST} is not answering yet."
  echo "Add the DNS record  A  app  ->  your server IP  in GoDaddy, wait 5-10 minutes, then run this script again."
fi

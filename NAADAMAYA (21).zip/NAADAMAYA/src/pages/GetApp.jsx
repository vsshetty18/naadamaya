import { useI18n } from '@/i18n'
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ArrowLeft, Download, Smartphone, Share, PlusSquare, MonitorSmartphone } from 'lucide-react'

import LegalLinks from '@/components/LegalLinks'
import logoMark from '@/assets/logo-mark.png'

/**
 * Page /app (signed in, inside the layout) and /get-app (public, for the sign-in footer): how to get NAADAMAYA on any device.
 *  Android  -> install from the browser (best) or download the APK file
 *  iPhone   -> Add to Home Screen (Apple does not allow APK files)
 *  Computer -> install from the browser, or open this page on a phone
 * The APK lives on the server at /downloads/NAADAMAYA.apk (see the owner's guide).
 */

const APK_URL = '/downloads/NAADAMAYA.apk'

function detect() {
  const ua = typeof navigator === 'undefined' ? '' : navigator.userAgent || ''
  if (/android/i.test(ua)) return 'android'
  if (/iphone|ipad|ipod/i.test(ua) || (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1)) return 'ios'
  return 'desktop'
}

function Step({ n, children }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brown-600 text-[0.75rem] font-semibold text-white">{n}</span>
      <span className="text-[0.95rem] leading-relaxed text-brown-700">{children}</span>
    </li>
  )
}

function Card({ icon: Icon, title, children }) {
  return (
    <section className="mt-5 rounded-2xl border border-brown-100 bg-white/70 p-5 shadow-sm">
      <h2 className="flex items-center gap-2 font-serif text-[1.15rem] font-semibold text-brown-900">
        <Icon className="h-5 w-5 text-brown-600" aria-hidden="true" />
        {title}
      </h2>
      {children}
    </section>
  )
}

export default function GetApp({ embedded = false }) {
  const { t } = useI18n()
  const [platform] = useState(detect)
  const [installEvent, setInstallEvent] = useState(null)
  const [installed, setInstalled] = useState(false)
  const [apkReady, setApkReady] = useState(false)

  useEffect(() => {
    const onPrompt = (e) => {
      e.preventDefault()
      setInstallEvent(e)
    }
    const onInstalled = () => setInstalled(true)
    window.addEventListener('beforeinstallprompt', onPrompt)
    window.addEventListener('appinstalled', onInstalled)
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  // Only show the APK button when the file really exists on the server.
  useEffect(() => {
    let alive = true
    fetch(APK_URL, { method: 'HEAD' })
      .then((r) => alive && setApkReady(r.ok && !(r.headers.get('content-type') || '').includes('text/html')))
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [])

  const runInstall = async () => {
    if (!installEvent) return
    installEvent.prompt()
    await installEvent.userChoice.catch(() => {})
    setInstallEvent(null)
  }

  const standalone = typeof window !== 'undefined' && window.matchMedia?.('(display-mode: standalone)').matches

  return (
    <div className={embedded ? 'pt-2' : 'min-h-screen bg-ivory px-4 pb-10 pt-6'}>
      <main className="mx-auto w-full max-w-xl">
        {!embedded && (
          <Link to="/" className="inline-flex items-center gap-1.5 text-[0.85rem] text-brown-500 hover:underline">
            <ArrowLeft className="h-4 w-4" aria-hidden="true" /> {t('app.back', 'Back')}
          </Link>
        )}

        <div className="mt-4 flex items-center gap-3">
          <img src={logoMark} alt="" className="h-14 w-14 rounded-full border border-brown-300/70" />
          <div>
            <h1 className="font-serif text-[1.6rem] font-semibold leading-tight text-brown-900">{t('app.title', 'Get the NAADAMAYA app')}</h1>
            <p className="text-[0.85rem] text-brown-500">sing. evolve. globally.</p>
          </div>
        </div>

        {(standalone || installed) && (
          <p className="mt-5 rounded-xl bg-sage-100 px-4 py-3 text-[0.92rem] text-brown-700">{t('app.installed', 'NAADAMAYA is already installed on this device.')}</p>
        )}

        {platform === 'android' && (
          <>
            <Card icon={Smartphone} title="Android">
              {installEvent && (
                <button type="button" onClick={runInstall} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-brown-600 px-5 py-3 text-[0.95rem] font-medium text-white">
                  <Download className="h-4 w-4" aria-hidden="true" /> {t('app.install', 'Install app')}
                </button>
              )}
              {apkReady && (
                <a href={APK_URL} download className="mt-3 flex w-full items-center justify-center gap-2 rounded-full border border-brown-600 px-5 py-3 text-[0.95rem] font-medium text-brown-700">
                  <Download className="h-4 w-4" aria-hidden="true" /> {t('app.apk', 'Download APK')}
                </a>
              )}
              {!installEvent && !apkReady && (
                <p className="mt-3 text-[0.92rem] text-brown-700">Open the Chrome menu (⋮) and tap <b>Install app</b> or <b>Add to Home screen</b>.</p>
              )}
            </Card>
            {apkReady && (
              <Card icon={Download} title="Installing the APK file">
                <ol className="mt-3 space-y-3">
                  <Step n="1">Tap <b>Download APK</b>. If Chrome warns that the file may be harmful, tap <b>Download anyway</b>.</Step>
                  <Step n="2">Open the downloaded file. If asked, allow <b>Install unknown apps</b> for Chrome, then go back.</Step>
                  <Step n="3">Tap <b>Install</b>, then <b>Open</b>.</Step>
                </ol>
              </Card>
            )}
          </>
        )}

        {platform === 'ios' && (
          <Card icon={Share} title="iPhone and iPad">
            <p className="mt-2 text-[0.92rem] text-brown-700">Apple does not allow APK files. Install NAADAMAYA from Safari instead. It works like an app.</p>
            <ol className="mt-3 space-y-3">
              <Step n="1">Open this page in <b>Safari</b>.</Step>
              <Step n="2">Tap the <b>Share</b> button <Share className="inline h-4 w-4" aria-hidden="true" />.</Step>
              <Step n="3">Choose <b>Add to Home Screen</b> <PlusSquare className="inline h-4 w-4" aria-hidden="true" />, then <b>Add</b>.</Step>
            </ol>
          </Card>
        )}

        {platform === 'desktop' && (
          <Card icon={MonitorSmartphone} title="Computer">
            {installEvent ? (
              <button type="button" onClick={runInstall} className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-brown-600 px-5 py-3 text-[0.95rem] font-medium text-white">
                <Download className="h-4 w-4" aria-hidden="true" /> Install on this computer
              </button>
            ) : (
              <p className="mt-2 text-[0.92rem] text-brown-700">In Chrome or Edge, use the install icon at the right of the address bar.</p>
            )}
            <p className="mt-3 text-[0.92rem] text-brown-700">For your phone, open <b>app.naadamaya.site/get-app</b> on it.</p>
          </Card>
        )}

        {!embedded && <LegalLinks className="mt-8" />}
      </main>
    </div>
  )
}

import { Link } from 'react-router-dom'

import { cn } from '@/utils/cn'

/** The public policy pages. Shown on the sign-in screen and on Profile. */
export const LEGAL_LINKS = [
  { to: '/app', label: 'Get the App' },
  { to: '/terms', label: 'Terms & Conditions' },
  { to: '/privacy', label: 'Privacy Policy' },
  { to: '/refunds', label: 'Cancellation & Refunds' },
  { to: '/pricing', label: 'Pricing' },
  { to: '/delivery', label: 'Delivery' },
  { to: '/contact', label: 'Contact Us' },
]

export default function LegalLinks({ className }) {
  return (
    <nav aria-label="Policies" className={cn('flex flex-wrap justify-center gap-x-4 gap-y-1.5 text-[0.78rem]', className)}>
      {LEGAL_LINKS.map((item) => (
        <Link key={item.to} to={item.to} className="text-brown-500 underline-offset-2 hover:underline">
          {item.label}
        </Link>
      ))}
    </nav>
  )
}

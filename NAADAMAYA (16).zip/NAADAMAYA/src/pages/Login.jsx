import { useState } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { AlertCircle, ArrowRight, Eye, EyeOff, Lock, Phone } from 'lucide-react'

import Button from '@/components/Button'
import HeroArt from '@/components/HeroArt'
import LanguageSwitch from '@/components/LanguageSwitch'
import LegalLinks from '@/components/LegalLinks'
import logoMark from '@/assets/logo-mark.png'
import { useAuth } from '@/context/AuthContext'
import { useI18n } from '@/i18n'
import { loginWithPassword, registerWithPassword } from '@/services/api/auth'
import { cn } from '@/utils/cn'

/**
 * Sign in or create an account with a phone number and a password.
 * The phone number is the account: one number is one NAADAMAYA account.
 * All rules (lockout, password strength) are enforced by the backend;
 * this screen only shows what it says.
 */

const COUNTRY_PREFIX = '+91'
const MIN_PASSWORD = 8

/** "98765 43210" -> "+9198765 43210". A number typed with its own "+" is sent as typed. */
function toPhone(input) {
  const text = input.trim()
  return text.startsWith('+') ? text : `${COUNTRY_PREFIX}${text.replace(/\D/g, '')}`
}

function errorMessage(err, t) {
  if (err?.isNetwork) return t('login.err.network', 'We could not reach NAADAMAYA. Check your connection and try again.')
  switch (err?.code) {
    case 'INVALID_PHONE_NUMBER':
      return err.message
    case 'INVALID_CREDENTIALS':
      return t('login.err.creds', 'Phone number or password is not correct.')
    case 'ACCOUNT_LOCKED':
      return err.message || t('login.err.locked', 'Too many wrong attempts. Please wait a few minutes.')
    case 'PHONE_TAKEN':
      return t('login.err.taken', 'This phone number already has an account. Please sign in.')
    case 'WEAK_PASSWORD':
      return err.message
    case 'RATE_LIMITED':
      return t('login.err.rate', 'Too many attempts. Please wait a minute and try again.')
    case 'ACCOUNT_DISABLED':
      return t('login.err.disabled', 'This account is not active.')
    default:
      return err?.message || t('login.err.generic', 'Something went wrong. Please try again.')
  }
}

export default function Login() {
  const { status, signIn } = useAuth()
  const { t } = useI18n()
  const location = useLocation()
  const destination = location.state?.from || '/'

  const [mode, setMode] = useState('signin') // 'signin' | 'signup'
  const [phoneInput, setPhoneInput] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState(null)

  const signup = mode === 'signup'

  async function submit(e) {
    e.preventDefault()
    if (busy || !ready) return
    if (signup && password !== confirm) {
      setError(t('login.err.match', 'The two passwords do not match.'))
      return
    }
    setBusy(true)
    setError(null)
    try {
      const fn = signup ? registerWithPassword : loginWithPassword
      const result = await fn(toPhone(phoneInput), password)
      signIn(result) // status becomes 'authenticated' and the redirect below takes over
    } catch (err) {
      setError(errorMessage(err, t))
      setBusy(false)
    }
  }

  // Already signed in (or just signed in): leave this screen.
  if (status === 'authenticated') return <Navigate to={destination} replace />

  const phoneDigits = phoneInput.replace(/\D/g, '')
  const phoneReady = phoneInput.trim().startsWith('+') ? phoneDigits.length >= 8 : phoneDigits.length === 10
  const ready = phoneReady && password.length >= (signup ? MIN_PASSWORD : 1) && (!signup || confirm.length > 0)

  return (
    <div className="relative min-h-dvh">
      {/* Hero with the logo */}
      <div className="relative isolate h-56 overflow-hidden sm:h-64">
        <HeroArt className="absolute inset-0 -z-10" />
        <div className="safe-top">
          <div className="mx-auto flex max-w-desktop items-center gap-3 px-4 pt-5 md:px-8">
            <span className="flex h-[3.4rem] w-[3.4rem] shrink-0 items-center justify-center overflow-hidden rounded-full border border-brown-300/70 bg-[#FEFEFE] shadow-soft md:h-16 md:w-16">
              <img src={logoMark} alt="" className="h-full w-full scale-[0.86] object-contain" draggable="false" />
            </span>
            <span className="flex flex-col">
              <span className="nm-wordmark text-[1.35rem] leading-none sm:text-[1.7rem] md:text-[2rem]">NAADAMAYA</span>
              <span className="nm-tagline mt-1.5 text-[0.52rem] sm:text-[0.6rem] md:text-[0.68rem]">sing. evolve. globally.</span>
            </span>
          </div>
        </div>
      </div>

      <main className="mx-auto -mt-6 w-full max-w-app px-4 pb-10">
        <section className="nm-card animate-fade-up px-5 py-7 sm:px-7">
          <form onSubmit={submit} noValidate>
            <h1 className="font-serif text-[1.9rem] font-semibold leading-tight text-brown-900">
              {signup ? t('login.createTitle', 'Create your account') : t('login.title', 'Welcome to NAADAMAYA')}
            </h1>
            <p className="nm-subtitle mt-2">
              {signup
                ? t('login.createSub', 'Choose a password to keep your practice safe.')
                : t('login.sub', 'Sign in with your phone number and password.')}
            </p>

            <label className="mt-6 block">
              <span className="mb-1.5 block text-[0.78rem] font-medium text-brown-600">{t('login.phone', 'Phone number')}</span>
              <span
                className={cn(
                  'flex h-[3.2rem] items-center gap-2 rounded-xl border bg-ivory-50 px-3 focus-within:border-brown-400 focus-within:ring-2 focus-within:ring-gold-300/60',
                  error ? 'border-status-bad' : 'border-gold-200'
                )}
              >
                <Phone className="h-4 w-4 shrink-0 text-brown-400" strokeWidth={1.8} aria-hidden="true" />
                <span className="border-r border-gold-200 pr-2 text-[0.95rem] font-medium text-brown-700">{COUNTRY_PREFIX}</span>
                <input
                  type="tel"
                  inputMode="tel"
                  name="username"
                  autoComplete="username"
                  autoFocus
                  value={phoneInput}
                  onChange={(e) => {
                    setPhoneInput(e.target.value)
                    setError(null)
                  }}
                  placeholder="98765 43210"
                  maxLength={20}
                  aria-label={t('login.phone', 'Phone number')}
                  className="min-w-0 flex-1 bg-transparent text-[1.05rem] tracking-wide text-brown-900 outline-none placeholder:text-brown-300"
                />
              </span>
            </label>

            <label className="mt-4 block">
              <span className="mb-1.5 block text-[0.78rem] font-medium text-brown-600">{t('login.password', 'Password')}</span>
              <span
                className={cn(
                  'flex h-[3.2rem] items-center gap-2 rounded-xl border bg-ivory-50 px-3 focus-within:border-brown-400 focus-within:ring-2 focus-within:ring-gold-300/60',
                  error ? 'border-status-bad' : 'border-gold-200'
                )}
              >
                <Lock className="h-4 w-4 shrink-0 text-brown-400" strokeWidth={1.8} aria-hidden="true" />
                <input
                  type={show ? 'text' : 'password'}
                  name="password"
                  autoComplete={signup ? 'new-password' : 'current-password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value)
                    setError(null)
                  }}
                  maxLength={128}
                  aria-label={t('login.password', 'Password')}
                  className="min-w-0 flex-1 bg-transparent text-[1.05rem] text-brown-900 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShow((v) => !v)}
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-brown-400 hover:text-brown-700"
                  aria-label={show ? t('login.hide', 'Hide password') : t('login.show', 'Show password')}
                >
                  {show ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
                </button>
              </span>
              {signup && (
                <span className="mt-1.5 block text-[0.74rem] text-brown-400">
                  {t('login.rule', 'At least 8 characters. Avoid common words and your phone number.')}
                </span>
              )}
            </label>

            {signup && (
              <label className="mt-4 block">
                <span className="mb-1.5 block text-[0.78rem] font-medium text-brown-600">{t('login.confirm', 'Type the password again')}</span>
                <span className="flex h-[3.2rem] items-center gap-2 rounded-xl border border-gold-200 bg-ivory-50 px-3 focus-within:border-brown-400 focus-within:ring-2 focus-within:ring-gold-300/60">
                  <Lock className="h-4 w-4 shrink-0 text-brown-400" strokeWidth={1.8} aria-hidden="true" />
                  <input
                    type={show ? 'text' : 'password'}
                    name="confirm"
                    autoComplete="new-password"
                    value={confirm}
                    onChange={(e) => {
                      setConfirm(e.target.value)
                      setError(null)
                    }}
                    maxLength={128}
                    aria-label={t('login.confirm', 'Type the password again')}
                    className="min-w-0 flex-1 bg-transparent text-[1.05rem] text-brown-900 outline-none"
                  />
                </span>
              </label>
            )}

            {error && <ErrorLine message={error} />}

            <Button type="submit" variant="primary" size="lg" fullWidth loading={busy} disabled={!ready} rightIcon={ArrowRight} className="mt-5">
              {signup ? t('login.create', 'Create account') : t('login.signin', 'Sign in')}
            </Button>

            <p className="mt-4 text-center text-[0.85rem] text-brown-500">
              {signup ? t('login.have', 'Already have an account?') : t('login.new', 'New to NAADAMAYA?')}{' '}
              <button
                type="button"
                onClick={() => {
                  setMode(signup ? 'signin' : 'signup')
                  setError(null)
                  setConfirm('')
                }}
                className="font-medium text-brown-600 underline-offset-2 hover:underline"
              >
                {signup ? t('login.signin', 'Sign in') : t('login.create', 'Create account')}
              </button>
            </p>
            {!signup && (
              <p className="mt-2 text-center text-[0.74rem] leading-snug text-brown-400">
                {t('login.forgot', 'Forgot your password? Write to naadamayasite@gmail.com from the number you signed up with and we will reset it.')}
              </p>
            )}
            <p className="mt-3 text-center text-[0.75rem] leading-snug text-brown-400">
              {t('login.one', 'One phone number is one NAADAMAYA account.')}
            </p>
          </form>
        </section>

        <LanguageSwitch className="mt-6 justify-center" />
        <LegalLinks className="mt-6" />
      </main>
    </div>
  )
}

function ErrorLine({ message }) {
  return (
    <p role="alert" className="mt-3 flex items-start gap-1.5 text-[0.82rem] text-status-bad">
      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={2} aria-hidden="true" />
      {message}
    </p>
  )
}

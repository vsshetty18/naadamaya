"""plan prices in other currencies

Revision ID: 0005
Revises: 0004
Create Date: 2026-11-20
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0005"
down_revision: Union[str, None] = "0004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("plans", sa.Column("prices", postgresql.JSONB(), nullable=False, server_default="{}"))
    # Starting prices for customers outside India (smallest unit: cents). Change them any time with SQL.
    op.execute("""UPDATE plans SET prices = '{"USD": 399}'::jsonb WHERE code = 'GO' AND prices = '{}'::jsonb""")
    op.execute("""UPDATE plans SET prices = '{"USD": 799}'::jsonb WHERE code = 'PRO' AND prices = '{}'::jsonb""")


def downgrade() -> None:
    op.drop_column("plans", "prices")

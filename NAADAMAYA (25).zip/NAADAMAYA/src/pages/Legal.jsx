import { useEffect } from 'react'
import { Link, Navigate, useLocation } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

import LegalLinks from '@/components/LegalLinks'
import logoMark from '@/assets/logo-mark.png'

/**
 * Public policy pages (no sign-in needed): /terms /privacy /refunds /pricing
 * /delivery /contact. They are plain text so a payment provider, a bank or an
 * SMS provider can read them without an account.
 *
 * Business details live in ONE place (BUSINESS) so they are easy to change.
 */

const BUSINESS = {
  name: 'NAADAMAYA',
  address: '227, PSK Hostel, 4th Main, 3rd Cross, Chamrajpet, Bangalore 560018, Karnataka, India',
  email: 'naadamayasite@gmail.com',
  phone: '+91 94488 38506',
  site: 'https://app.naadamaya.site',
  updated: '20 November 2026',
}

function P({ children }) {
  return <p className="mt-3 text-[0.95rem] leading-relaxed text-brown-700">{children}</p>
}

function H({ children }) {
  return <h2 className="mt-7 font-serif text-[1.25rem] font-semibold leading-tight text-brown-900">{children}</h2>
}

function List({ items }) {
  return (
    <ul className="mt-3 list-disc space-y-1.5 pl-5 text-[0.95rem] leading-relaxed text-brown-700">
      {items.map((item) => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  )
}

function ContactLines() {
  return (
    <P>
      {BUSINESS.name}
      <br />
      {BUSINESS.address}
      <br />
      Email: <a className="underline" href={`mailto:${BUSINESS.email}`}>{BUSINESS.email}</a>
      <br />
      Phone: <a className="underline" href="tel:+919448838506">{BUSINESS.phone}</a>
    </P>
  )
}

const PAGES = {
  terms: {
    title: 'Terms & Conditions',
    body: (
      <>
        <P>
          These terms apply when you use {BUSINESS.name} at {BUSINESS.site} (the &ldquo;service&rdquo;). By signing in you
          agree to them. If you do not agree, please do not use the service.
        </P>
        <H>What the service does</H>
        <P>
          {BUSINESS.name} helps you improve your singing. You upload or record a performance, and the service compares it
          with a reference and reports what it can measure, such as pitch and timing. The results are practice feedback.
          They are not a professional judgement or a guarantee of any result.
        </P>
        <H>Feedback can be wrong</H>
        <P>
          {BUSINESS.name} could make mistakes. The analysis is made by software, and it can mishear, misjudge or miss
          things, especially with noisy recordings, poor microphones, unusual voices, ornamentation, or songs that do not
          match the reference. Treat the scores and tips as practice guidance only. They are not a professional,
          medical or vocal-health opinion. If singing hurts or strains your voice, stop and speak to a teacher or a doctor.
        </P>
        <H>Your account</H>
        <List
          items={[
            'You sign in with your mobile number, or an email address you have added to your account, and a password you choose. You are responsible for keeping your password secret and for everything done with your account. If you forget it, you can reset it with a code we send by SMS to your mobile number.',
            'You must give a mobile number that belongs to you. You must be at least 13 years old. If you are under 18, you may use the service only with the consent and supervision of a parent or guardian.',
            'Do not share your password or SMS codes with anyone, and do not try to access another person’s account.',
          ]}
        />
        <H>Plans, credits and payments</H>
        <List
          items={[
            'Each analysis uses one credit. The Free plan gives 10 credits a month. Paid plans (Go and Pro) give the credits shown on the Pricing page for 30 days from purchase.',
            'Paid plans are one-time payments. They do not renew automatically, and we never charge you again unless you choose to buy again.',
            'Unused credits do not carry over when a plan ends or changes. When a paid plan ends, your account returns to the Free plan.',
            'Payments are processed by Razorpay. We never see or store your card, UPI or bank details.',
            'Refunds are described on the Cancellation & Refunds page.',
          ]}
        />
        <H>Your recordings</H>
        <P>
          You keep ownership of everything you upload. You give us permission to store and process it only to provide the
          service to you. Upload only audio you have the right to use. Do not upload anything unlawful, abusive or that
          infringes someone else&rsquo;s rights.
        </P>
        <H>Acceptable use</H>
        <P>
          Please do not misuse the service: no attempts to break or overload it, to reach other users&rsquo; data, or to
          resell access. We may suspend an account that does.
        </P>
        <H>Availability and changes</H>
        <P>
          We work to keep the service available, but we do not promise it will always be uninterrupted or error-free. We
          may improve, change or remove features, and we may update these terms. The date at the top of this page shows
          the latest version.
        </P>
        <H>Liability</H>
        <P>
          To the extent the law allows, our responsibility for any claim related to the service is limited to the amount
          you paid us in the 3 months before the claim.
        </P>
        <H>Governing law</H>
        <P>These terms are governed by the laws of India. Courts in Bengaluru, Karnataka have jurisdiction.</P>
        <H>Contact</H>
        <ContactLines />
      </>
    ),
  },

  privacy: {
    title: 'Privacy Policy',
    body: (
      <>
        <P>
          This page explains what {BUSINESS.name} collects, why, how long we keep it, and the choices you have. We
          collect only what the service needs, and we follow the laws of India, including the Digital Personal Data
          Protection Act, 2023, as they apply to us.
        </P>
        <H>What we collect</H>
        <List
          items={[
            'Your mobile number. It is your account and your sign-in name.',
            'Your password, which we never store as readable text. We keep only a one-way scrambled version (a hash) that nobody, including us, can turn back into your password.',
            'Details you choose to add: your name, username, profile photo, email (if you add one you can also sign in with it, so it can belong to only one account), gender, vocal range, singing level, and your preferred languages, genres and style.',
            'The audio you upload or record (reference tracks and your own singing) and the analysis made from it: scores, measurements, reports, tips and your attempt history.',
            'The songs you choose, which means the titles, artists and languages of what you sang, with the date and time of each attempt.',
            'Your practice settings and activity, such as your daily goal, streak, weekly report and tool settings.',
            'Your plan, credit use and payment records (payment id, amount and status).',
            'Technical data such as your IP address, device and browser type, and sign-in times, used for security, to limit abuse and to fix problems.',
          ]}
        />
        <H>What we do not collect</H>
        <P>
          We do not see or store your card, UPI or bank details. Those go directly to Razorpay. We do not use
          advertising or tracking cookies, we do not sell your data, and we do not use your recordings to train
          artificial intelligence models.
        </P>
        <H>How we use it</H>
        <List
          items={[
            'To sign you in, keep your account secure and send you a code when you reset a forgotten password.',
            'To analyse your singing and show your reports, practice plans and progress.',
            'To process payments and activate your plan.',
            'To prevent abuse, find and fix errors, and keep the service running well.',
            'To look at overall usage of the service, such as how many people sing and which songs are popular. A small number of authorised people who run the service can see accounts, phone numbers and which songs were sung, only for support, safety and running the service.',
          ]}
        />
        <H>Who handles data for us</H>
        <List
          items={[
            'Razorpay, to process payments.',
            'Fast2SMS, which receives your mobile number and the code, only to deliver the SMS when you reset your password.',
            'Amazon Web Services (AWS), our cloud hosting provider, which stores the service and its data on our behalf. Our servers are in Sydney, Australia, so your data is stored and processed outside India.',
          ]}
        />
        <P>
          We share data with these providers only so they can do that job. We may also share data if the law or a court
          requires it, or to protect the safety of people or the service. We do not share your recordings or reports with
          other users. Your reports are private unless you choose to share a picture of your score yourself.
        </P>
        <H>On your device</H>
        <P>
          The app keeps your sign-in and some settings (such as your language and tool preferences) in your device&rsquo;s
          storage. If you install the app, a small copy of the app itself is saved so the practice tools can work offline.
          This is not used to track you. Signing out removes your sign-in from the device.
        </P>
        <H>Security</H>
        <P>
          Passwords and SMS codes are stored only as one-way hashes. Connections to the service are encrypted. After
          several wrong password attempts an account is locked for a short time. Access to our servers is limited. No
          system is perfectly secure, but we take reasonable steps to protect your data. If a breach that affects you
          happens, we will tell you and the authorities as the law requires.
        </P>
        <H>How long we keep it</H>
        <List
          items={[
            'Your audio recordings are deleted automatically about 90 days after you upload them. Your reports, scores and song names stay in your account until you delete it.',
            'Your account data stays while your account is active.',
            'Secure backups of our database are kept for up to 14 days and then removed.',
            'Payment records may be kept as long as the law requires for accounting and tax.',
          ]}
        />
        <H>Your rights and choices</H>
        <P>
          You can see and change your details on the Profile screen. You can delete your account yourself from the
          Profile screen: your songs, recordings, reports and profile are then permanently deleted. Payment records are
          kept, unlinked from your identity, for legal and accounting reasons. You also have the right to ask us for a
          copy of the data we hold about you, to have it corrected or erased, to withdraw your consent, and to complain.
          Write to{' '}
          <a className="underline" href={`mailto:${BUSINESS.email}`}>{BUSINESS.email}</a> from the mobile number on your
          account. We reply within 7 days and act on requests within 30 days. If you are not satisfied, you may complain
          to the Data Protection Board of India.
        </P>
        <H>Children</H>
        <P>
          The service is not meant for children under 13. People under 18 may use it only with the consent and
          supervision of a parent or guardian. We do not show advertising or track children. If you think a child has
          given us data without permission, please contact us and we will remove it.
        </P>
        <H>Changes to this policy</H>
        <P>If we change how we handle data in a way that matters, we will update this page and its date, and tell you in the app where that is needed.</P>
        <H>Grievance contact</H>
        <P>For any privacy question or complaint, contact the person responsible for {BUSINESS.name}:</P>
        <ContactLines />
      </>
    ),
  },

  refunds: {
    title: 'Cancellation & Refunds',
    body: (
      <>
        <H>Cancellation</H>
        <P>
          Paid plans are one-time payments for 30 days. They do not renew automatically, so there is nothing to cancel.
          When the 30 days end, your account returns to the Free plan and you are not charged again.
        </P>
        <H>Refunds</H>
        <List
          items={[
            'You can ask for a refund within 24 hours of your payment. Write to us from the contact details below with your registered mobile number and the payment id from your Razorpay receipt.',
            'Refund requests made after 24 hours are not accepted.',
            'If an approved refund applies, we process it within 24 hours of approving your request, and it goes back to the original payment method.',
            'Your bank or card network may take 5 to 7 working days to show the money in your account.',
          ]}
        />
        <H>Payment taken but plan not active</H>
        <P>
          If money was deducted but your plan did not activate, write to us straight away with your payment id. We will
          either activate the plan or refund the full amount. Razorpay also automatically refunds payments that could not
          be completed.
        </P>
        <H>How to ask</H>
        <ContactLines />
      </>
    ),
  },

  pricing: {
    title: 'Pricing',
    body: (
      <>
        <P>Customers in India pay in Indian Rupees (INR). Customers outside India may pay in US dollars (USD) or their local currency where available, at the price shown to you before you pay; your bank or card issuer may add currency conversion fees or taxes. Paid plans are one-time payments for 30 days and do not renew automatically.</P>
        <div className="mt-5 grid gap-4 sm:grid-cols-3">
          {[
            { name: 'Free', price: '₹0', credits: '10 analysis credits per month', note: 'Basic comparison report, standard analysis.' },
            { name: 'Go', price: '₹199', credits: '30 analysis credits for 30 days', note: 'Detailed comparison report, advanced analysis, AI suggestions.' },
            { name: 'Pro', price: '₹449', credits: '100 analysis credits for 30 days', note: 'Complete AI report, advanced insights and tips, priority processing, early access to new features.' },
          ].map((plan) => (
            <div key={plan.name} className="rounded-2xl border border-brown-200/70 bg-ivory-50/70 p-4">
              <p className="font-serif text-[1.3rem] font-semibold text-brown-900">{plan.name}</p>
              <p className="mt-1 font-serif text-[1.7rem] font-semibold text-brown-900">{plan.price}</p>
              <p className="mt-2 text-[0.9rem] font-medium text-brown-700">{plan.credits}</p>
              <p className="mt-1.5 text-[0.85rem] leading-relaxed text-brown-600">{plan.note}</p>
            </div>
          ))}
        </div>
        <P>Each analysis uses one credit. Unused credits do not carry over when a plan ends. Payments are handled securely by Razorpay.</P>
      </>
    ),
  },

  delivery: {
    title: 'Delivery',
    body: (
      <>
        <P>
          {BUSINESS.name} is a digital service. There is nothing to ship. Your plan and credits are added to your account
          as soon as your payment is confirmed, usually within a few seconds.
        </P>
        <P>
          If your payment succeeded but your plan has not appeared after a few minutes, refresh the page. If it still
          has not appeared, contact us with your payment id and we will fix it or refund you.
        </P>
        <ContactLines />
      </>
    ),
  },

  contact: {
    title: 'Contact Us',
    body: (
      <>
        <P>We are happy to help with questions about your account, payments or refunds.</P>
        <ContactLines />
        <P>Please include your registered mobile number and, for payments, the payment id from your receipt.</P>
      </>
    ),
  },
}

export default function Legal() {
  const { pathname } = useLocation()
  const content = PAGES[pathname.replace(/^\/+|\/+$/g, '')]
  useEffect(() => {
    if (!content) return undefined
    const before = document.title
    document.title = `${content.title} | NAADAMAYA`
    return () => {
      document.title = before
    }
  }, [content])

  if (!content) return <Navigate to="/" replace />

  return (
    <div className="relative min-h-dvh">
      <header className="mx-auto flex w-full max-w-desktop items-center gap-3 px-4 pt-6 md:px-8">
        <Link to="/" className="flex items-center gap-3">
          <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-brown-300/70 bg-ivory-50/70 shadow-soft">
            <img src={logoMark} alt="" className="h-9 w-9 object-contain" draggable="false" />
          </span>
          <span className="nm-wordmark text-[1.4rem] leading-none">NAADAMAYA</span>
        </Link>
      </header>

      <main className="mx-auto w-full max-w-tablet px-4 pb-12 pt-6 md:px-8">
        <Link to="/" className="inline-flex items-center gap-1.5 text-[0.85rem] text-brown-500 hover:underline">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Back
        </Link>
        <article className="nm-card mt-3 px-5 py-7 sm:px-8">
          <h1 className="font-serif text-[1.9rem] font-semibold leading-tight text-brown-900">{content.title}</h1>
          <p className="mt-1 text-[0.8rem] text-brown-500">Last updated {BUSINESS.updated}</p>
          {content.body}
        </article>
        <LegalLinks className="mt-8" />
        <p className="mt-3 text-center text-[0.75rem] text-brown-400">&copy; {BUSINESS.name}</p>
      </main>
    </div>
  )
}

"""
Builds the search-engine and AI-friendly files:
  public/<page>/index.html   plain HTML pages that crawlers read without running JavaScript
  public/sitemap.xml  public/robots.txt  public/llms.txt  public/llms-full.txt  public/seo.css

Edit the text in this file, then run:   python3 seo/generate.py
Only say things here that are true of the app. No invented reviews, ratings or user counts.
"""
import html
import json
import os

SITE = "https://app.naadamaya.site"
BRAND = "NAADAMAYA"
TAGLINE = "sing. evolve. globally."
EMAIL = "naadamayasite@gmail.com"
UPDATED = "2026-11-20"
OG = f"{SITE}/og-image.png"
PUBLIC = os.path.join(os.path.dirname(__file__), "..", "public")

PRICING = [
    ("Free", "0", "10 analysis credits every month. Basic comparison report."),
    ("Go", "199", "30 analysis credits for 30 days. Detailed comparison report, advanced analysis, AI suggestions."),
    ("Pro", "449", "100 analysis credits for 30 days. Complete AI report, advanced insights and tips, priority processing, early access to new features."),
]

FAQ = [
    ("What is NAADAMAYA?",
     "NAADAMAYA is a singing practice app. You give it the original song and your own recording, and it compares them. It shows where your pitch, timing and steadiness differ from the original and suggests what to practise next."),
    ("Is NAADAMAYA free?",
     "You can start free. The Free plan includes 10 analysis credits every month, and each analysis uses one credit. The Go plan (₹199) gives 30 credits and the Pro plan (₹449) gives 100 credits, each for 30 days. Customers outside India are shown the price in US dollars (or their local currency) at checkout. Paid plans are one-time payments and never renew automatically. The practice tools (tanpura, tuner, tala keeper, ear training) do not use credits."),
    ("How do I compare my singing with the original song?",
     "Add the original song as the reference by uploading a file or recording it. Add your own singing the same way. NAADAMAYA then analyses both and gives you a report with scores, a timeline of where you differ, and practice suggestions."),
    ("What does the analysis measure?",
     "It measures pitch accuracy, rhythm and timing, and how steady your notes are. Where it can, it also gives pronunciation and breath insights. Beginners see plain-word feedback. Advanced singers and professionals also see expert numbers and focused drills."),
    ("Is the feedback always correct?",
     "No. NAADAMAYA could make mistakes. It is software, and noisy rooms, poor microphones, unusual voices and heavy ornamentation can confuse it. Use the feedback as practice guidance and trust your teacher and your ear."),
    ("Can beginners use it? What about professional singers?",
     "Yes to both. You choose a singing level (beginner, intermediate, advanced or professional) and the feedback adapts to it. Beginners get simple language and a few priorities. Advanced and professional singers get stricter measurements and drills."),
    ("Which devices and languages does it support?",
     "It works in any modern browser on phones and computers, and there is an Android app. You can add it to your phone's home screen. The interface is available in English, Hindi and Kannada."),
    ("Does it work offline?",
     "The practice tools (tanpura, tuner and tala keeper) work offline after you have opened the app once with internet. Analysing a song needs an internet connection."),
    ("How do I sign in?",
     "Create an account with your mobile number and a password. You can add an email address, and then sign in with either one. If you forget your password, a reset code is sent by SMS to your mobile number."),
    ("Are my recordings private?",
     "Yes. Your recordings and reports are private to your account. Audio files are deleted automatically about 90 days after upload, and you can delete your account and all your data from the Profile screen. Read the full Privacy Policy for details."),
    ("Does NAADAMAYA work for Indian classical, film and devotional songs?",
     "It compares two recordings, so you can use it with any song you have a clear reference for. It includes a tanpura and a tala keeper, and a Sa selector so you can practise in your own scale. Results are best with clear recordings and a reference in the same key and tempo."),
    ("How do I delete my account?",
     "Open the Profile screen and choose Delete account. Your songs, recordings, reports and profile are permanently deleted."),
]

NAV = [("/about/", "About"), ("/features/", "Features"), ("/how-it-works/", "How it works"),
       ("/compare-singing-with-original-song/", "Compare singing"), ("/singing-practice-tools/", "Practice tools"), ("/faq/", "FAQ")]


def e(s):
    return html.escape(s, quote=True)


def bullets(items):
    return "<ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"


# ---------------------------------------------------------------- pages
PAGES = {}

PAGES["about"] = dict(
    path="/about/",
    title="NAADAMAYA: Compare Your Singing With the Original Song",
    desc="NAADAMAYA is a singing practice app. Compare your singing with the original song and get clear feedback on pitch, timing and steadiness. Free to start.",
    h1="Compare your singing with the original song",
    lead="NAADAMAYA is a singing improvement app for beginners and professionals. Give it the original song and your own recording. It shows where you drift from the original in pitch, rhythm and steadiness, then tells you what to practise next.",
    sections=[
        ("What is NAADAMAYA?",
         "<p>NAADAMAYA (sing. evolve. globally.) helps singers hear what they cannot easily hear themselves. Instead of guessing, you see your recording next to the original along the whole song. The report is written in plain words, with a score, a timeline and practice suggestions.</p>"),
        ("Who is it for?",
         "<p>You choose your singing level, and the feedback changes with it.</p>" + bullets([
             "<strong>Beginners</strong> get simple words and a small number of priorities.",
             "<strong>Intermediate singers</strong> get the full comparison report.",
             "<strong>Advanced singers</strong> get stricter measurements and focused drills.",
             "<strong>Professionals</strong> also get expert numbers, such as how far notes drift, in cents.",
         ])),
        ("What you get",
         bullets([
             "A side-by-side comparison of your singing and the original song.",
             "Scores and a timeline for pitch, rhythm and timing, and steadiness. Pronunciation and breath insights where possible.",
             "A practice loop: replay the weak sections, slow the audio down, and try again.",
             "A daily goal, a practice streak and a weekly report.",
             "Free practice tools: tanpura, tuner, tala keeper, ear training and a Sa selector.",
             "A report you can share as a picture. Your reports stay private unless you share that picture yourself.",
         ])),
        ("Languages and devices",
         "<p>NAADAMAYA works in any modern browser on phones and computers, as an Android app, and as an app you add to your home screen. The interface is in English, Hindi and Kannada. The practice tools also work offline.</p>"),
        ("Pricing",
         "<p>Start free. Paid plans are one-time payments for 30 days and do not renew automatically.</p>" + bullets(
             [f"<strong>{n}</strong>: ₹{p}. {d}" for n, p, d in PRICING])),
        ("An honest note",
         "<p>NAADAMAYA could make mistakes. Treat its feedback as practice guidance and trust your teacher and your ear. It is not a replacement for a good teacher.</p>"),
    ],
)

PAGES["features"] = dict(
    path="/features/",
    title="NAADAMAYA Features: Singing Analysis, Practice Tools, Levels",
    desc="Everything in NAADAMAYA: compare your singing with the original, pitch and rhythm feedback, practice loop, tanpura, tuner, tala keeper, ear training and more.",
    h1="NAADAMAYA features",
    lead="Everything a singer needs to practise with focus: a comparison against the original song, feedback that fits your level, and free tools for daily riyaz.",
    sections=[
        ("Compare with the original song",
         bullets(["Upload or record the original song, then upload or record your singing.",
                  "See where your pitch, timing and steadiness differ from the original.",
                  "Read a report in plain words, with a score and a timeline of the whole song."])),
        ("Feedback that fits your level",
         bullets(["Beginner, intermediate, advanced and professional levels.",
                  "Beginners get simple language and a few priorities.",
                  "Advanced and professional singers get expert numbers and targeted drills."])),
        ("Practice loop and habits",
         bullets(["Replay the weak sections of a song again and again.",
                  "Slow the audio down without changing the pitch.",
                  "Set a daily goal, keep a streak, and read a weekly practice report."])),
        ("Practice tools",
         bullets(["<strong>Tanpura</strong>: a drone in your chosen Sa.",
                  "<strong>Tuner</strong>: see the note you are singing, and how many cents sharp or flat.",
                  "<strong>Tala keeper</strong>: a steady rhythm cycle to sing against.",
                  "<strong>Ear training</strong>: tap a swara to hear it against your Sa, then sing it back.",
                  "<strong>Sa selector</strong>: pick the scale that suits your voice.",
                  "These tools do not use analysis credits, and they work offline once the app has been opened."])),
        ("Made for everyone",
         bullets(["Interface in English, Hindi and Kannada.",
                  "Website, Android app and home-screen install.",
                  "Share your score as a picture. Your reports stay private otherwise.",
                  "Delete your account and all your data yourself, any time."])),
        ("Plans",
         bullets([f"<strong>{n}</strong>: ₹{p}. {d}" for n, p, d in PRICING])),
    ],
)

PAGES["how-it-works"] = dict(
    path="/how-it-works/",
    title="How NAADAMAYA Works: Singing Analysis in 4 Steps",
    desc="How NAADAMAYA compares your singing with the original song: add two recordings, get a report on pitch, timing and steadiness, then practise the weak parts.",
    h1="How NAADAMAYA works",
    lead="Four steps from a recording to a practice plan.",
    sections=[
        ("1. Add the original song",
         "<p>Upload the original recording, or record it. This is the reference your singing is compared with.</p>"),
        ("2. Add your singing",
         "<p>Upload or record your own version. Use a quiet room. Headphones help you sing along without the original leaking into the microphone.</p>"),
        ("3. NAADAMAYA analyses both",
         "<p>The analysis lines your recording up with the reference and measures:</p>" + bullets([
             "<strong>Pitch</strong>: how close each note is to the original, in cents (a cent is one hundredth of a semitone).",
             "<strong>Rhythm and timing</strong>: whether you start and finish notes together with the original.",
             "<strong>Steadiness</strong>: how steady you hold each note.",
             "<strong>Pronunciation and breath</strong>: extra insights where they can be measured.",
         ]) + "<p>One credit is used for each analysis.</p>"),
        ("4. Read the report and practise",
         "<p>The report shows a score, a timeline of where you differ, and practice suggestions written for your level. Replay the weak sections, slow them down, and record again to see your progress.</p>"),
        ("Tips for better results",
         bullets(["Sing in a quiet room and keep the microphone at a steady distance.",
                  "Sing in the same key and at the same tempo as the original.",
                  "Use a clean reference recording, not one with heavy echo or noise.",
                  "Do several short attempts rather than one long tired one."])),
        ("What it cannot do",
         "<p>NAADAMAYA could make mistakes. Noisy recordings, poor microphones, unusual voices and heavy ornamentation can confuse the analysis. It does not replace a teacher, and it is not a vocal-health or medical tool.</p>"),
    ],
)

PAGES["compare-singing-with-original-song"] = dict(
    path="/compare-singing-with-original-song/",
    title="Compare Your Singing With the Original Song Online",
    desc="How to check your singing against the original song: record both, compare pitch and timing, and find exactly which lines to practise. Try it free with NAADAMAYA.",
    h1="How to compare your singing with the original song",
    lead="Listening back to yourself is hard, because your ear forgives your own mistakes. A side-by-side comparison with the original shows exactly where you drift.",
    sections=[
        ("Why compare with the original?",
         "<p>When you sing along with a song, you hear a blend of both voices. It is easy to feel that you were on pitch when you were slightly flat, or to rush a line without noticing. Comparing two clean recordings removes the guesswork.</p>"),
        ("How to do it with NAADAMAYA",
         "<ol><li>Upload or record the original song.</li><li>Upload or record your own singing of the same song.</li><li>Open the report. It shows where your pitch, rhythm and steadiness differ from the original.</li><li>Replay the weak sections slowly, then record again.</li></ol>"),
        ("What to look for in the result",
         bullets(["Lines where you are consistently sharp or flat.",
                  "Places where you enter early or late.",
                  "Long notes that wobble or fade.",
                  "Sections that improve between attempts, and sections that do not."])),
        ("Getting a fair comparison",
         bullets(["Use the same key. If the original is too high or low for you, change your Sa and sing in your own scale.",
                  "Use a clear reference recording.",
                  "Record in a quiet place with a steady microphone distance."])),
        ("Free to start",
         "<p>The Free plan includes 10 analyses every month. No card is needed to begin.</p>"),
        ("Remember",
         "<p>NAADAMAYA could make mistakes. Use the result as guidance, alongside your teacher and your own ear.</p>"),
    ],
)

PAGES["singing-practice-tools"] = dict(
    path="/singing-practice-tools/",
    title="Free Tanpura, Tuner and Tala Practice Tools for Singers",
    desc="Free singing practice tools from NAADAMAYA: a tanpura drone, a note tuner, a tala keeper and ear training. They work offline and use no credits.",
    h1="Free tanpura, tuner and tala tools for singers",
    lead="Daily riyaz needs a drone, a reference note and a steady beat. NAADAMAYA includes all three, and they work on your phone even without internet.",
    sections=[
        ("Tanpura",
         "<p>A drone you can set to your own Sa, so every note you sing has a steady reference underneath it.</p>"),
        ("Tuner",
         "<p>Sing a note and see which note it is and how many cents sharp or flat you are. Useful for checking your Sa and for slow, careful practice.</p>"),
        ("Tala keeper",
         "<p>A steady rhythm cycle (tala) with a clearly marked first beat (sam), claps (tali) and wave (khali), so you can practise keeping time.</p>"),
        ("Ear training",
         "<p>Tap a swara to hear it against your Sa, then sing it back. Short daily practice builds a reliable ear.</p>"),
        ("Sa selector",
         "<p>Pick the Sa (the base note) that suits your voice. The tanpura, tuner and exercises follow your choice.</p>"),
        ("Free, and works offline",
         "<p>The tools do not use analysis credits. After you have opened NAADAMAYA once with internet, the tanpura, tuner and tala keeper keep working without a connection. <a href=\"/practice\">Open the practice tools</a>.</p>"),
    ],
)

PAGES["faq"] = dict(
    path="/faq/",
    title="NAADAMAYA FAQ: Pricing, Privacy, Accuracy and More",
    desc="Answers about NAADAMAYA: what it is, if it is free, how accurate it is, which devices and languages it supports, privacy, offline use and deleting your account.",
    h1="Frequently asked questions",
    lead="Short, honest answers about NAADAMAYA.",
    sections=[(q, f"<p>{e(a)}</p>") for q, a in FAQ],
    faq=True,
)

# Hindi and Kannada landing pages (please have a native speaker review them)
PAGES["hi"] = dict(
    path="/hi/", lang="hi",
    title="NAADAMAYA: अपने गायन की तुलना मूल गीत से करें",
    desc="NAADAMAYA एक गायन अभ्यास ऐप है। अपने गायन की मूल गीत से तुलना करें और सुर, ताल और स्थिरता पर साफ़ सुझाव पाएँ। शुरुआत मुफ़्त है।",
    h1="अपने गायन की तुलना मूल गीत से करें",
    lead="NAADAMAYA शुरुआती से लेकर पेशेवर गायकों तक के लिए एक ऐप है। मूल गीत और अपनी रिकॉर्डिंग दीजिए। यह दिखाता है कि आप सुर, ताल और स्थिरता में कहाँ मूल गीत से हटते हैं, और आगे क्या अभ्यास करें।",
    sections=[
        ("आपको क्या मिलता है", bullets([
            "आपके गायन और मूल गीत की आमने-सामने तुलना।",
            "सुर (पिच), लय और समय, और स्थिरता का स्कोर और टाइमलाइन।",
            "कमज़ोर हिस्सों को दोहराने, धीमा सुनने और फिर से गाने की सुविधा।",
            "रोज़ का लक्ष्य, लगातार अभ्यास की गिनती और साप्ताहिक रिपोर्ट।",
            "मुफ़्त अभ्यास उपकरण: तानपुरा, ट्यूनर, ताल कीपर, कान का अभ्यास और सा चुनने की सुविधा।",
        ])),
        ("आपके स्तर के अनुसार सुझाव", "<p>शुरुआती, मध्यम, उन्नत और पेशेवर, अपना स्तर चुनिए। शुरुआती गायकों को सरल भाषा में कुछ मुख्य बातें मिलती हैं। उन्नत और पेशेवर गायकों को सटीक माप और अभ्यास मिलते हैं।</p>"),
        ("भाषा और डिवाइस", "<p>ऐप हिन्दी, कन्नड़ और अंग्रेज़ी में है। यह फ़ोन और कंप्यूटर के ब्राउज़र में, Android ऐप के रूप में और होम स्क्रीन पर जोड़कर चलता है। अभ्यास उपकरण बिना इंटरनेट के भी चलते हैं।</p>"),
        ("कीमत", "<p>मुफ़्त में शुरू करें: हर महीने 10 विश्लेषण। Go योजना ₹199 में 30 विश्लेषण (30 दिन)। Pro योजना ₹449 में 100 विश्लेषण (30 दिन)। भुगतान एक बार का है, अपने-आप नवीनीकरण नहीं होता।</p>"),
        ("एक ज़रूरी बात", "<p>NAADAMAYA से गलतियाँ हो सकती हैं। इसके सुझाव अभ्यास के मार्गदर्शन की तरह लें और अपने गुरु तथा अपने कान पर भरोसा रखें।</p>"),
    ],
    cta="ऐप खोलें", home="मुख्य पृष्ठ",
)

PAGES["kn"] = dict(
    path="/kn/", lang="kn",
    title="NAADAMAYA: ನಿಮ್ಮ ಗಾಯನವನ್ನು ಮೂಲ ಹಾಡಿನೊಂದಿಗೆ ಹೋಲಿಸಿ",
    desc="NAADAMAYA ಒಂದು ಗಾಯನ ಅಭ್ಯಾಸ ಆ್ಯಪ್. ನಿಮ್ಮ ಗಾಯನವನ್ನು ಮೂಲ ಹಾಡಿನೊಂದಿಗೆ ಹೋಲಿಸಿ, ಸ್ವರ, ತಾಳ ಮತ್ತು ಸ್ಥಿರತೆಯ ಬಗ್ಗೆ ಸ್ಪಷ್ಟ ಸಲಹೆ ಪಡೆಯಿರಿ. ಉಚಿತವಾಗಿ ಆರಂಭಿಸಿ.",
    h1="ನಿಮ್ಮ ಗಾಯನವನ್ನು ಮೂಲ ಹಾಡಿನೊಂದಿಗೆ ಹೋಲಿಸಿ",
    lead="NAADAMAYA ಆರಂಭಿಕರಿಂದ ವೃತ್ತಿಪರರವರೆಗಿನ ಗಾಯಕರಿಗಾಗಿ ಇರುವ ಆ್ಯಪ್. ಮೂಲ ಹಾಡು ಮತ್ತು ನಿಮ್ಮ ರೆಕಾರ್ಡಿಂಗ್ ನೀಡಿ. ಸ್ವರ, ತಾಳ ಮತ್ತು ಸ್ಥಿರತೆಯಲ್ಲಿ ನೀವು ಎಲ್ಲಿ ಮೂಲದಿಂದ ಬೇರೆಯಾಗುತ್ತೀರಿ ಮತ್ತು ಮುಂದೆ ಏನು ಅಭ್ಯಾಸ ಮಾಡಬೇಕು ಎಂದು ಇದು ತೋರಿಸುತ್ತದೆ.",
    sections=[
        ("ನಿಮಗೆ ಏನು ಸಿಗುತ್ತದೆ", bullets([
            "ನಿಮ್ಮ ಗಾಯನ ಮತ್ತು ಮೂಲ ಹಾಡಿನ ಪಕ್ಕ-ಪಕ್ಕದ ಹೋಲಿಕೆ.",
            "ಸ್ವರ (ಪಿಚ್), ಲಯ ಮತ್ತು ಸಮಯ, ಹಾಗೂ ಸ್ಥಿರತೆಯ ಸ್ಕೋರ್ ಮತ್ತು ಟೈಮ್‌ಲೈನ್.",
            "ದುರ್ಬಲ ಭಾಗಗಳನ್ನು ಪುನರಾವರ್ತಿಸಿ, ನಿಧಾನವಾಗಿ ಕೇಳಿ, ಮತ್ತೆ ಹಾಡುವ ಸೌಲಭ್ಯ.",
            "ದಿನದ ಗುರಿ, ನಿರಂತರ ಅಭ್ಯಾಸದ ಲೆಕ್ಕ ಮತ್ತು ವಾರದ ವರದಿ.",
            "ಉಚಿತ ಅಭ್ಯಾಸ ಸಾಧನಗಳು: ತಂಬೂರಿ, ಟ್ಯೂನರ್, ತಾಳ ಕೀಪರ್, ಕಿವಿ ತರಬೇತಿ ಮತ್ತು ಸ ಆಯ್ಕೆ.",
        ])),
        ("ನಿಮ್ಮ ಮಟ್ಟಕ್ಕೆ ತಕ್ಕ ಸಲಹೆ", "<p>ಆರಂಭಿಕ, ಮಧ್ಯಮ, ಮುಂದುವರಿದ ಮತ್ತು ವೃತ್ತಿಪರ ಎಂದು ನಿಮ್ಮ ಮಟ್ಟವನ್ನು ಆರಿಸಿ. ಆರಂಭಿಕರಿಗೆ ಸರಳ ಭಾಷೆಯಲ್ಲಿ ಕೆಲವು ಮುಖ್ಯ ಅಂಶಗಳು ಸಿಗುತ್ತವೆ. ಮುಂದುವರಿದ ಮತ್ತು ವೃತ್ತಿಪರ ಗಾಯಕರಿಗೆ ನಿಖರ ಅಳತೆ ಮತ್ತು ಅಭ್ಯಾಸಗಳು ಸಿಗುತ್ತವೆ.</p>"),
        ("ಭಾಷೆ ಮತ್ತು ಸಾಧನಗಳು", "<p>ಆ್ಯಪ್ ಕನ್ನಡ, ಹಿಂದಿ ಮತ್ತು ಇಂಗ್ಲಿಷ್‌ನಲ್ಲಿ ಲಭ್ಯ. ಫೋನ್ ಮತ್ತು ಕಂಪ್ಯೂಟರ್ ಬ್ರೌಸರ್‌ನಲ್ಲಿ, Android ಆ್ಯಪ್ ಆಗಿ ಮತ್ತು ಹೋಮ್ ಸ್ಕ್ರೀನ್‌ಗೆ ಸೇರಿಸಿ ಬಳಸಬಹುದು. ಅಭ್ಯಾಸ ಸಾಧನಗಳು ಇಂಟರ್ನೆಟ್ ಇಲ್ಲದೆಯೂ ಕೆಲಸ ಮಾಡುತ್ತವೆ.</p>"),
        ("ಬೆಲೆ", "<p>ಉಚಿತವಾಗಿ ಆರಂಭಿಸಿ: ಪ್ರತಿ ತಿಂಗಳು 10 ವಿಶ್ಲೇಷಣೆ. Go ಯೋಜನೆ ₹199ಕ್ಕೆ 30 ವಿಶ್ಲೇಷಣೆ (30 ದಿನ). Pro ಯೋಜನೆ ₹449ಕ್ಕೆ 100 ವಿಶ್ಲೇಷಣೆ (30 ದಿನ). ಪಾವತಿ ಒಂದು ಬಾರಿಯದು, ತಾನಾಗಿ ನವೀಕರಣವಾಗುವುದಿಲ್ಲ.</p>"),
        ("ಒಂದು ಮುಖ್ಯ ಮಾತು", "<p>NAADAMAYA ಯಿಂದ ತಪ್ಪುಗಳಾಗಬಹುದು. ಇದರ ಸಲಹೆಗಳನ್ನು ಅಭ್ಯಾಸದ ಮಾರ್ಗದರ್ಶನವಾಗಿ ಬಳಸಿ, ನಿಮ್ಮ ಗುರುಗಳು ಮತ್ತು ನಿಮ್ಮ ಕಿವಿಯನ್ನು ನಂಬಿ.</p>"),
    ],
    cta="ಆ್ಯಪ್ ತೆರೆಯಿರಿ", home="ಮುಖ್ಯ ಪುಟ",
)

ALTERNATES = [("en", "/about/"), ("hi", "/hi/"), ("kn", "/kn/"), ("x-default", "/about/")]

# ---------------------------------------------------------------- templates
CSS = """:root{--bg:#FDFAF4;--ink:#301C12;--ink2:#5E3720;--accent:#93582F;--line:#E7D3B0;--card:#FFFFFF}
@media (prefers-color-scheme:dark){:root{--bg:#1d1510;--ink:#F5EBDD;--ink2:#D9C3A5;--accent:#E0A875;--line:#4a3626;--card:#271b13}}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.65 Georgia,'Times New Roman','Noto Sans Devanagari','Noto Sans Kannada',serif}
a{color:var(--accent)}
.wrap{max-width:46rem;margin:0 auto;padding:0 16px}
header.site{padding:14px 0;border-bottom:1px solid var(--line)}
header.site .wrap{display:flex;flex-wrap:wrap;gap:8px 16px;align-items:center;justify-content:space-between}
.brand{font-weight:700;letter-spacing:.18em;text-decoration:none;color:var(--ink)}
nav.top{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:.9rem}
h1{font-size:clamp(1.8rem,5vw,2.5rem);line-height:1.2;margin:1.6rem 0 .6rem}
h2{font-size:1.35rem;line-height:1.3;margin:2rem 0 .4rem}
.lead{font-size:1.15rem;color:var(--ink2)}
ul,ol{padding-left:1.3rem}li{margin:.35rem 0}
.cta{display:inline-block;margin:1.4rem 0;padding:.8rem 1.5rem;border-radius:999px;background:var(--accent);color:#fff;text-decoration:none;font-weight:600}
@media (prefers-color-scheme:dark){.cta{color:#1d1510}}
.note{border:1px solid var(--line);background:var(--card);border-radius:12px;padding:.8rem 1rem;font-size:.95rem}
footer.site{margin-top:3rem;padding:1.4rem 0 2.4rem;border-top:1px solid var(--line);font-size:.88rem;color:var(--ink2)}
footer.site a{margin-right:12px;white-space:nowrap}
"""


def head(p, schema):
    lang = p.get("lang", "en")
    url = SITE + p["path"]
    alt = "".join(f'<link rel="alternate" hreflang="{l}" href="{SITE}{u}">\n' for l, u in ALTERNATES) if p["path"] in ("/about/", "/hi/", "/kn/") else ""
    locale = {"en": "en_IN", "hi": "hi_IN", "kn": "kn_IN"}[lang]
    return f"""<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{e(p['title'])}</title>
<meta name="description" content="{e(p['desc'])}">
<link rel="canonical" href="{url}">
{alt}<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
<meta name="theme-color" content="#FDFAF4">
<link rel="icon" type="image/png" href="/favicon.png">
<link rel="apple-touch-icon" href="/icons/apple-touch-icon.png">
<link rel="stylesheet" href="/seo.css">
<meta property="og:type" content="website">
<meta property="og:site_name" content="{BRAND}">
<meta property="og:title" content="{e(p['title'])}">
<meta property="og:description" content="{e(p['desc'])}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{OG}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="NAADAMAYA: sing. evolve. globally.">
<meta property="og:locale" content="{locale}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{e(p['title'])}">
<meta name="twitter:description" content="{e(p['desc'])}">
<meta name="twitter:image" content="{OG}">
<script type="application/ld+json">{json.dumps(schema, ensure_ascii=False)}</script>
</head>
"""


def page_html(key, p):
    lang = p.get("lang", "en")
    cta = p.get("cta", "Open NAADAMAYA")
    home = p.get("home", "Home")
    crumbs = [{"@type": "ListItem", "position": 1, "name": BRAND, "item": SITE + "/"},
              {"@type": "ListItem", "position": 2, "name": p["h1"], "item": SITE + p["path"]}]
    graph = [
        {"@type": "WebPage", "@id": SITE + p["path"] + "#webpage", "url": SITE + p["path"], "name": p["title"],
         "description": p["desc"], "inLanguage": lang, "dateModified": UPDATED,
         "isPartOf": {"@id": SITE + "/#website"}, "about": {"@id": SITE + "/#app"},
         "primaryImageOfPage": {"@type": "ImageObject", "url": OG}},
        {"@type": "BreadcrumbList", "itemListElement": crumbs},
    ]
    if p.get("faq"):
        graph.append({"@type": "FAQPage", "mainEntity": [
            {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in FAQ]})
    schema = {"@context": "https://schema.org", "@graph": graph}
    nav = "".join(f'<a href="{u}">{n}</a>' for u, n in NAV) if lang == "en" else \
        f'<a href="/about/">English</a><a href="/hi/">हिन्दी</a><a href="/kn/">ಕನ್ನಡ</a>'
    body = "".join(f"<section><h2>{e(h)}</h2>{c}</section>\n" for h, c in p["sections"])
    foot = "".join(f'<a href="{u}">{n}</a>' for u, n in [("/privacy", "Privacy Policy"), ("/terms", "Terms"),
                   ("/pricing", "Pricing"), ("/refunds", "Refunds"), ("/contact", "Contact"), ("/get-app", "Get the app")])
    return head(p, schema) + f"""<body>
<header class="site"><div class="wrap"><a class="brand" href="/">{BRAND}</a><nav class="top" aria-label="Main">{nav}</nav></div></header>
<main class="wrap">
<h1>{e(p['h1'])}</h1>
<p class="lead">{e(p['lead'])}</p>
<p><a class="cta" href="/">{e(cta)}</a></p>
{body}<p><a class="cta" href="/">{e(cta)}</a></p>
<p class="note">{BRAND} could make mistakes. Use its feedback as practice guidance.</p>
</main>
<footer class="site"><div class="wrap"><p>{BRAND} &middot; {TAGLINE}</p><p>{foot}</p><p>Contact: <a href="mailto:{EMAIL}">{EMAIL}</a></p></div></footer>
</body>
</html>
"""


def write(path, text):
    full = os.path.join(PUBLIC, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(text)


def main():
    write("seo.css", CSS)
    for key, p in PAGES.items():
        write(p["path"].strip("/") + "/index.html", page_html(key, p))

    # sitemap
    urls = [("/", "1.0", "weekly")] + [(p["path"], "0.8" if key not in ("hi", "kn") else "0.6", "monthly") for key, p in PAGES.items()] + \
           [("/get-app", "0.5", "monthly"), ("/practice", "0.5", "monthly"), ("/pricing", "0.5", "monthly"),
            ("/privacy", "0.3", "yearly"), ("/terms", "0.3", "yearly"), ("/refunds", "0.3", "yearly"),
            ("/delivery", "0.2", "yearly"), ("/contact", "0.3", "yearly")]
    alt_for = {"/about/", "/hi/", "/kn/"}
    rows = []
    for u, pr, fr in urls:
        links = ""
        if u in alt_for:
            links = "".join(f'\n    <xhtml:link rel="alternate" hreflang="{l}" href="{SITE}{x}"/>' for l, x in ALTERNATES)
        rows.append(f"  <url>\n    <loc>{SITE}{u}</loc>\n    <lastmod>{UPDATED}</lastmod>\n    <changefreq>{fr}</changefreq>\n    <priority>{pr}</priority>{links}\n  </url>")
    write("sitemap.xml", '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n' + "\n".join(rows) + "\n</urlset>\n")

    # robots.txt: everyone, including search and AI crawlers, may read the public pages
    bots = ["Googlebot", "Bingbot", "DuckDuckBot", "Applebot", "OAI-SearchBot", "GPTBot", "ChatGPT-User", "ClaudeBot",
            "Claude-SearchBot", "Claude-User", "PerplexityBot", "Perplexity-User", "Google-Extended", "Amazonbot", "CCBot", "meta-externalagent"]
    robots = "# NAADAMAYA: search engines and AI assistants are welcome to read the public pages.\n"
    robots += "User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /downloads/\n\n"
    for b in bots:
        robots += f"User-agent: {b}\nAllow: /\nDisallow: /api/\n\n"
    robots += f"Sitemap: {SITE}/sitemap.xml\n"
    write("robots.txt", robots)

    # llms.txt (short) and llms-full.txt (everything), for AI assistants
    about = PAGES["about"]
    llms = f"""# {BRAND}

> {BRAND} ({TAGLINE}) is a singing practice app. You give it the original song and your own recording. It compares them and shows where your pitch, rhythm and steadiness differ, then suggests what to practise. It suits beginners to professional singers. It is available as a website, an Android app and a home-screen app, in English, Hindi and Kannada. It can make mistakes, so its feedback is practice guidance, not a replacement for a teacher.

Key facts:
- Name: {BRAND}. Website and app: {SITE}
- Plans: Free (10 analysis credits a month), Go (₹199, 30 credits for 30 days), Pro (₹449, 100 credits for 30 days). Customers outside India see the price in US dollars at checkout. Paid plans are one-time payments and do not renew automatically.
- Free practice tools (no credits): tanpura, tuner, tala keeper, ear training, Sa selector. The tools work offline after the first visit.
- Sign in with mobile number or email, and a password.
- Privacy: reports are private. Audio is deleted about 90 days after upload. Users can delete their account and data themselves.
- Contact: {EMAIL}

## Pages
- [About]({SITE}/about/): what NAADAMAYA is and who it is for
- [Features]({SITE}/features/): all features
- [How it works]({SITE}/how-it-works/): the four steps and what is measured
- [Compare your singing with the original song]({SITE}/compare-singing-with-original-song/): a guide
- [Practice tools]({SITE}/singing-practice-tools/): tanpura, tuner, tala keeper, ear training
- [FAQ]({SITE}/faq/): pricing, privacy, accuracy, devices, languages
- [Hindi]({SITE}/hi/) and [Kannada]({SITE}/kn/) summaries
- [Pricing]({SITE}/pricing), [Privacy Policy]({SITE}/privacy), [Terms]({SITE}/terms), [Refunds]({SITE}/refunds), [Contact]({SITE}/contact)

## Optional
- [Full text of this site]({SITE}/llms-full.txt)
"""
    write("llms.txt", llms)

    import re

    def plain(h):
        h = re.sub(r"</li>", "\n", h)
        h = re.sub(r"<li>", "- ", h)
        h = re.sub(r"</p>|</ol>|</ul>", "\n", h)
        return html.unescape(re.sub(r"<[^>]+>", "", h)).strip()

    full = f"# {BRAND}: full text\n\nSource: {SITE}  (updated {UPDATED})\n"
    for key in ("about", "features", "how-it-works", "compare-singing-with-original-song", "singing-practice-tools"):
        p = PAGES[key]
        full += f"\n\n# {p['h1']}\nURL: {SITE}{p['path']}\n\n{p['lead']}\n"
        for h, c in p["sections"]:
            full += f"\n## {h}\n{plain(c)}\n"
    full += "\n\n# Frequently asked questions\n"
    for q, a in FAQ:
        full += f"\n## {q}\n{a}\n"
    write("llms-full.txt", full)
    print("pages:", ", ".join(p["path"] for p in PAGES.values()))


if __name__ == "__main__":
    main()
